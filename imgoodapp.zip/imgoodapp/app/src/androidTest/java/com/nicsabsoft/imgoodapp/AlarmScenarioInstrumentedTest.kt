package com.nicsabsoft.imgoodapp

import android.os.Looper
import android.support.test.InstrumentationRegistry
import android.support.test.runner.AndroidJUnit4
import com.nicsabsoft.imgoodapp.core.alarm.AlarmScenario

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*
import java.util.logging.Handler

/**
 * Instrumented test, which will execute on an Android device.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4::class)
class AlarmScenarioInstrumentedTest {

    @Test
    fun useAlarmScenario() {
        // Context of the app under test.
        val alarmScenario = AlarmScenario(InstrumentationRegistry.getTargetContext(), null)

        alarmScenario.init("")

        assertEquals(alarmScenario.getAlamSteps()?.isEmpty(), true )

        alarmScenario.init("toto")

        assertEquals(alarmScenario.getAlamSteps()?.isEmpty(), true )

        alarmScenario.init("test_alarmstep")

        assertEquals(alarmScenario.getAlamSteps()?.isEmpty(), false )

        assertEquals(alarmScenario.getAlamSteps()?.size == 5, true )
        assertEquals(alarmScenario.getDuration() == 35L, true )


    }
}
