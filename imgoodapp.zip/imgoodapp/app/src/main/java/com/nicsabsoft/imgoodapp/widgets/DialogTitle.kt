/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.nicsabsoft.imgoodapp.widgets

import android.content.Context
import android.text.TextUtils
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView

import com.nicsabsoft.imgoodapp.R


/**
 * The Class DialogTitle.
 */
class DialogTitle
/**
 * Instantiates a new dialog title.
 * @param context the context
 * @param attrs the attrs
 */
(context: Context, attrs: AttributeSet) : FrameLayout(context, attrs) {

    /** The m inflater.  */
    private val mInflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    /** The m dialog tite text view.  */
    private val mDialogTiteTextView: TextView

    /**
     * Gets the text.
     * @return the text
     */
    val text: CharSequence
        get() = mDialogTiteTextView.text

    init {

        val view = mInflater.inflate(R.layout.uiwidgets_dialog_title, null)
        mDialogTiteTextView = view.findViewById<View>(R.id.uiwidgets_dialog_title) as TextView
        addView(view)

        val a = context.obtainStyledAttributes(attrs, R.styleable.UIWidgetsDialogTitle)
        val value = a.getString(R.styleable.UIWidgetsDialogTitle_text)
        if (!TextUtils.isEmpty(value)) {
            setText(value)
        }
        a.recycle()
    }

    /**
     * Sets the text.
     * @param title the new text
     */
    fun setText(title: String) {
        mDialogTiteTextView.text = title
    }

}
