package com.nicsabsoft.imgoodapp.widgets

import android.content.pm.PackageManager
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.MenuItem

import com.nicsabsoft.imgoodapp.TheApplication
import com.nicsabsoft.imgoodapp.utils.MySharePreferences
import com.nicsabsoft.imgoodapp.utils.PermissionManager


abstract class MyAppCompatActivity : AppCompatActivity(), ActivityCompat.OnRequestPermissionsResultCallback {

    // UI references.
    protected var mTheApplication: TheApplication? = null

    /**
     * the m PermissionManager
     */
    private val mPermissionManager = PermissionManager()

    /** The m MySharePreferences.  */
    protected var mMySharePreferences: MySharePreferences? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mTheApplication = application as TheApplication

        mMySharePreferences = (application as TheApplication).mySharePreferences

    }


    override fun onResume() {
        super.onResume()
        mPermissionManager.checkAllPermission(this)
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>,
                                            grantResults: IntArray) {
        when (requestCode) {
            PermissionManager.MY_ALL_PERMISSIONS_REQUEST -> {
                if (permissions.size > 0) {
                    // If request is cancelled, the result arrays are empty.
                    if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                        // permission was granted, yay! Do the
                        // contacts-related task you need to do.
                        Log.i(TAG, "onRequestPermissionsResult permission granted, let's go! " + permissions[0])

                    } else {

                        // permission denied, boo! Disable the
                        // functionality that depends on this permission.
                        Log.e(TAG, "onRequestPermissionsResult permission not granted")
                        finish()
                        return
                    }
                }

            }
        }// other 'case' lines to check for other
        // permissions this app might request
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                //Write your logic here
                onBackPressed()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    companion object {

        private val TAG = "MyAppCompatActivity"
    }


}

