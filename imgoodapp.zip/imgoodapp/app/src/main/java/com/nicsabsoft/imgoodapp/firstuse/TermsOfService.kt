/*
 * Copyright 2019 nicsabsoft, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * nicsabsoft, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with nicsabsoft.
 */
package com.nicsabsoft.imgoodapp.firstuse

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.ActionBar
import android.support.v7.app.AppCompatActivity
import android.view.MenuItem
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

import com.nicsabsoft.imgoodapp.MainActivity
import com.nicsabsoft.imgoodapp.R
import com.nicsabsoft.imgoodapp.TheApplication


/**
 * The Class TermsOfService.
 */
class TermsOfService : AppCompatActivity(), View.OnClickListener {

    /**
     * The m web view.
     */
    private var mWebView: WebView? = null

    /**
     * The m mAgreeButton.
     */
    private var mAgreeButton: View? = null

    /**
     *
     */
    @SuppressLint("SetJavaScriptEnabled")
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val actionBar = supportActionBar
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
            actionBar.setLogo(R.drawable.empty)
            actionBar.setHomeAsUpIndicator(null)
            actionBar.setTitle(R.string.splash_screen_tos)
        }
        setContentView(R.layout.terms_of_service)
        setProgressBarIndeterminateVisibility(true)

        val intent = intent
        if (intent != null) {
            if (intent.getBooleanExtra(INTENT_PARAM_ACCEPT_BUTTON, false)) {
                mAgreeButton = findViewById(R.id.agreeButton)
                mAgreeButton!!.visibility = View.VISIBLE
                if (mAgreeButton != null) {
                    mAgreeButton!!.setOnClickListener(this)
                }
            }
        }
        mWebView = findViewById<View>(R.id.webView) as WebView
        mWebView!!.settings.javaScriptEnabled = true
        mWebView!!.webViewClient = WebClient()

        mWebView!!.loadUrl(getString(R.string.eula_url))
    }

    /**
     * The Class WebClient.
     */
    private inner class WebClient : WebViewClient() {

        /**
         * Should override url loading.
         *
         * @param view the view
         * @param url  the url
         * @return true, if successful
         */
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            view.loadUrl(url)
            return false
        }

        override fun onReceivedError(view: WebView, errorCode: Int, description: String, failingUrl: String) {
            Toast.makeText(this@TermsOfService, "Oh no! $description", Toast.LENGTH_SHORT).show()
        }

        /**
         * On page finished.
         *
         * @param view the view
         * @param url  the url
         */
        override fun onPageFinished(view: WebView, url: String) {
            setSupportProgressBarIndeterminateVisibility(false)
        }
    }

    /**
     * On options item selected.
     *
     * @param item the item
     * @return true, if successful
     */
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onClick(v: View) {
        if (v.id == R.id.agreeButton) {
            val intent = Intent(this, (application as TheApplication).getMainActivity())
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }
    }

    companion object {

        /**
         * The INTENT_PARAM_ACCEPT_BUTTON.
         */
        val INTENT_PARAM_ACCEPT_BUTTON = "INTENT_PARAM_ACCEPT_BUTTON"
    }

}

