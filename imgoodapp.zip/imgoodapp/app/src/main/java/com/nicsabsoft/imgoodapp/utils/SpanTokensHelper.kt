/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.nicsabsoft.imgoodapp.utils

import android.text.SpannableStringBuilder
import android.text.method.LinkMovementMethod
import android.text.method.MovementMethod
import android.text.style.CharacterStyle
import android.widget.TextView


/**
 * The Class SpanTokensHelper.
 */
/**
 * Instantiates a new span tokens helper.
 */
class SpanTokensHelper {

    /**
     * Sets the link movement method.
     * @param textView the new link movement method
     */
    fun setLinkMovementMethod(textView: TextView?) {
        if (textView != null) {
            val movementMethod = textView.movementMethod
            if (movementMethod == null || movementMethod !is LinkMovementMethod) {
                textView.movementMethod = LinkMovementMethod.getInstance()
            }
        }
    }

    /**
     * Delete span tokens.
     * @param text the text
     * @param token the token
     * @return the char sequence
     */
    fun deleteSpanTokens(text: CharSequence, token: String): CharSequence {
        var retText = text
        val tokenLen = token.length
        val start = retText.toString().indexOf(token) + tokenLen
        val end = retText.toString().indexOf(token, start)

        if (start > -1 && end > -1) {
            // Copy the spannable string to a mutable spannable string
            val ssb = SpannableStringBuilder(retText)
            // Delete the tokens before and after the span
            ssb.delete(end, end + tokenLen)
            ssb.delete(start - tokenLen, start)

            retText = ssb
        }
        return retText

    }

    /**
     * Sets the span between tokens.
     * @param text the text
     * @param token the token
     * @param cs the cs
     * @return the char sequence
     */
    fun setSpanBetweenTokens(text: CharSequence, token: String, vararg cs: CharacterStyle): CharSequence {
        var retText = text
        // Start and end refer to the points where the span will apply
        val tokenLen = token.length
        val start = retText.toString().indexOf(token) + tokenLen
        val end = retText.toString().indexOf(token, start)

        if (start > -1 && end > -1) {
            // Copy the spannable string to a mutable spannable string
            val ssb = SpannableStringBuilder(retText)
            for (c in cs)
                ssb.setSpan(c, start, end, 0)

            // Delete the tokens before and after the span
            ssb.delete(end, end + tokenLen)
            ssb.delete(start - tokenLen, start)

            retText = ssb
        }
        return retText
    }

    /**
     * Gets the text between tokens.
     * @param text the text
     * @param token the token
     * @return the text between tokens
     */
    fun getTextBetweenTokens(text: CharSequence, token: String): CharSequence? {
        // Start and end refer to the points where the span will apply
        val tokenLen = token.length
        val start = text.toString().indexOf(token) + tokenLen
        val end = text.toString().indexOf(token, start)
        return if (start > -1 && end > -1) {
            text.subSequence(start, end)
        } else null
    }
}
