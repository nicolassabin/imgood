package com.nicsabsoft.imgoodapp


import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.ProgressDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.Bundle
import android.telephony.TelephonyManager
import android.util.Log
import com.nicsabsoft.imgoodapp.widgets.MyAppCompatActivity
import com.nicsabsoft.imgoodapp.core.AppService
import com.nicsabsoft.imgoodapp.utils.MySharePreferences
import kotlinx.android.synthetic.main.activity_operationvalidate.*
import android.view.animation.AnimationUtils
import android.media.MediaPlayer
import android.os.AsyncTask
import android.os.Handler
import android.view.View
import android.view.animation.Animation
import android.widget.ProgressBar
import android.widget.Toast
import com.nicsabsoft.imgoodapp.core.http.HttpRequestHelper
import com.nicsabsoft.imgoodapp.utils.MySMSManager
import kotlinx.android.synthetic.main.activity_operationtest.*


open class AppBasedActivity : MyAppCompatActivity() {

    companion object {

        private const val LOG_TAG = "AppBasedActivity";

        //private const val DEFAULT_VOLUME_VALUE = 20f

        const val NOTIF_ID = 1020

    }

    /** The m mTelephonyManager.  */
    protected var mTelephonyManager: TelephonyManager? = null

    /** The m HttpRequestHelper.  */
    protected var mHttpRequestHelper: HttpRequestHelper? = null

    /** The m MySMSManager.  */
    protected var mMySMSManager: MySMSManager? = null

    /** The m mProgressBar.  */
    protected var mProgressBar: ProgressBar? = null;

    /** The m mReceiverSms.  */
    private var mReceiverSms: BroadcastReceiver? = null

    /** The m mAsyncTask.  */
    private var mAsyncTask : AsyncTask<String, Void, Int>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d( LOG_TAG, "onCreate")
        super.onCreate(savedInstanceState)

        mHttpRequestHelper = HttpRequestHelper(this, getString(R.string.serverurl))

        mMySMSManager = MySMSManager(this)

        mTelephonyManager = this.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

        mReceiverSms = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                Log.d(LOG_TAG, "SMS correctly sent")
                displayInfo(context.getString(R.string.sms_sent))
                this@AppBasedActivity.unregisterReceiver(mReceiverSms)
            }
        }

    }

    override fun onDestroy() {
        Log.d( LOG_TAG, "onDestroy")
        mAsyncTask?.cancel(true)
        super.onDestroy()

    }

    protected fun setNextAlarm()
    {
        Log.d( LOG_TAG, "setNextAlarm")
        // Variable to hold service class name
        val serviceClass = AppService::class.java

        // Initialize a new Intent instance
        val intent = Intent(applicationContext, serviceClass)
        intent.setPackage(application.packageName)
        intent.putExtra(AppService.PARAM_ACTION, AppService.ACTION_SET_ALARM)
        intent.putExtra(AppService.EXTRA_SETALARM_NEXTDAY, true)
        startService(intent)
    }

    protected fun displayInfo(text: String){
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }

    protected fun sendNotification(msgSMSText: String, msgText: String) {
        Log.d( LOG_TAG, "sendNotification")
        mTheApplication?.cancelNotification(NOTIF_ID)
        if (resources.getBoolean(R.bool.notification_useservice)) {
            val intent = Intent(applicationContext, AppService::class.java)
            intent.setPackage(application.packageName)
            intent.putExtra(AppService.PARAM_ACTION, AppService.ACTION_NOTIF_ACTION)
            intent.putExtra(AppService.NOTIF_SMS_TEXT, msgSMSText)
            intent.putExtra(AppService.NOTIF_MESSAGE_TEXT, msgText)
            startService(intent)
        }
        else
        {
            val smsPhonenumbers = mMySharePreferences?.getStringPreference(Constants.SMS_PHONENUMBERS)
            mAsyncTask =
            object : AsyncTask<String, Void, Int>() {

                override fun onPreExecute() {
                    mProgressBar?.visibility = View.VISIBLE
                    registerReceiver(mReceiverSms, IntentFilter(MySMSManager.SMS_SENT))
                }

                override fun doInBackground(vararg params: String): Int? {
                    Log.d( LOG_TAG, "sendNotification doInBackground")
                    if (smsPhonenumbers != null && !smsPhonenumbers.isEmpty())
                    {
                        if (mMySMSManager!!.notifyBySMS(smsPhonenumbers,
                                        msgText)){
                            return 1
                        }

                    }
                    else
                    {
                        Log.d(LOG_TAG, "sendNotification no smsPhonenumbers!")
                    }
                    return 0
                }

                override fun onPostExecute(result: Int) {
                    Log.d( LOG_TAG, "sendNotification onPostExecute")
                    mProgressBar?.visibility = View.GONE
                    if (result < 1) {
                        displayInfo(resources.getString(R.string.sendmessage_error))
                        unregisterReceiver(mReceiverSms)
                    }
                }
            }
            mAsyncTask?.execute()

        }
    }

    protected fun sendAlertMessage() {
        Log.d( LOG_TAG, "sendAlertMessage")
        if (resources.getBoolean(R.bool.notification_useservice)) {
            val intent = Intent(applicationContext, AppService::class.java)
            intent.setPackage(application.packageName)
            intent.putExtra(AppService.PARAM_ACTION, AppService.ACTION_SEND_ALERT)
            startService(intent)
        }
        else
        {
            val emailToAdr = mMySharePreferences?.getStringPreference(Constants.EMAILS_ADR)
            mAsyncTask =
                    object : AsyncTask<String, Void, Int>() {

                        override fun onPreExecute() {
                            mProgressBar?.visibility = View.VISIBLE

                        }

                        override fun doInBackground(vararg params: String): Int? {
                            Log.d( LOG_TAG, "sendAlertMessage doInBackground")
                            if (emailToAdr != null && !emailToAdr.isEmpty())
                            {
                                return mHttpRequestHelper!!.postRequestAlert(getString(R.string.app_name),
                                        getString(R.string.alert_message_text),
                                        getString(R.string.alert_subject_text),
                                        emailToAdr)

                            }
                            else
                            {
                                Log.d(LOG_TAG, "sendAlertMessage no emailToAdr!")
                            }
                            return 300
                        }

                        override fun onPostExecute(result: Int) {
                            Log.d( LOG_TAG, "sendAlertMessage onPostExecute")
                            mProgressBar?.visibility = View.GONE
                            if (result < 300) {
                                displayInfo( resources.getString(R.string.sendmessage_successfully_sent)
                                        + " " + emailToAdr)
                            }
                            else
                            {
                                displayInfo( resources.getString(R.string.sendmessage_error))
                            }
                        }
                    }
            mAsyncTask?.execute()

        }
    }

}

