/*
 * Copyright 2019 nicsabsoft, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * nicsabsoft, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with nicsabsoft.
 */
package com.nicsabsoft.imgoodapp.firstuse

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v7.app.AppCompatActivity
import android.text.style.TextAppearanceSpan
import android.util.Log
import android.view.*
import android.view.View.OnClickListener
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.nicsabsoft.imgoodapp.R
import com.nicsabsoft.imgoodapp.TheApplication
import com.nicsabsoft.imgoodapp.utils.SpanTokensHelper
import com.nicsabsoft.imgoodapp.widgets.SwipePageListener
import com.nicsabsoft.imgoodapp.widgets.SwiperControl

class WizardActivity : AppCompatActivity(), OnClickListener, SwipePageListener {

    /** The SwiperControl.  */
    private var mSwiperControl: SwiperControl? = null

    /** The m span tokens helper.  */
    protected var mSpanTokensHelper = SpanTokensHelper()

    private var mbLaunchMain: Boolean = true

    /**
     *
     */
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        //finishOnStartedTooEarly()
        overridePendingTransition(0, 0)

        mbLaunchMain = intent.getBooleanExtra(EXTRA_LAUNCH_MAINACTIVITY, true)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        val actionBar = supportActionBar
        actionBar?.hide()
        setContentView(R.layout.wizard_activity)
        setControls()
    }

    /**
     * Finishes the activity if app hasn't got past SplashLogoActivity.
     */
    /*private fun finishOnStartedTooEarly() {
        val parentActivity = parent
        if (parentActivity != null && parentActivity is SplashLogoActivity) {
            finish()
        }
    }*/

    fun setControls() {
        mSwiperControl = findViewById<View>(R.id.swiper_control) as SwiperControl
        if (mSwiperControl != null) {
            val res = resources
            mSwiperControl!!.setAdapter(WizardAdapter(res.getTextArray(R.array.wizard_maintitles_strings),
                    res.getTextArray(R.array.wizard_titles_strings),
                    res.getIntArray(R.array.wizard_titles_colors),
                    res.getTextArray(R.array.wizard_strings)))

            if (findViewById<View>(R.id.wizard_next) != null) {
                mSwiperControl!!.setPageChangeListner(this)
            }
            mSwiperControl!!.startAutoScroll(15000)
            val context = baseContext
            if (context != null && mSwiperControl!!.circlePageIndicator != null) {
                mSwiperControl!!.circlePageIndicator!!.strokeColor = ContextCompat.getColor(context, R.color.circle_page_indicator_stroke)
            }
        }

        var button: View? = findViewById(R.id.skip_wizard_activity)
        if (button != null) {
            button.setOnClickListener(this)
            if (mbLaunchMain){
                button.visibility = View.VISIBLE
            }
            else
            {
                button.visibility = View.INVISIBLE
            }

        }

        button = findViewById(R.id.wizard_next)
        if (button != null) {
            button.setOnClickListener(this)
            button.visibility = View.VISIBLE
        }
    }

    /**
     *
     */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
            else -> {
            }
        }

        return super.onOptionsItemSelected(item)
    }

    /**
     * On click.
     * @param v the v
     */
    override fun onClick(v: View) {
        if (v.id == R.id.skip_wizard_activity) {
            launchNextStep()
            finish()
        } else if (v.id == R.id.wizard_next && launchNextStepWhenNotScrolling()) {
            finish()
        }
    }

    /**
     * Launches the next step
     */
    private fun launchNextStep() {
        if (resources.getBoolean(R.bool.enable_eula_screen)) {
            Log.d(LOG_TAG, "launchNextStep -> EULA")
            termsOfServices()
        } else {
            Log.d(LOG_TAG, "launchNextStep -> MAIN")
            launchMain()
        }
    }

    /**
     * Launch auth when not scrolling.
     */
    private fun launchNextStepWhenNotScrolling(): Boolean {
        if (!mSwiperControl!!.scrollOnce()) {
            launchNextStep()
            return true
        }
        return false
    }

    /**
     * Launch auth flow
     */
    private fun launchMain() {
        Log.d(LOG_TAG, "launchMain -> mbLaunchMain " + mbLaunchMain)
        if (mbLaunchMain){
            val intent = Intent(this, (application as TheApplication).getMainActivity())
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
        }
        else{
            finish()
        }

    }

    /**
     * Handle on page scrolled - do nothing.
     * @param position the position
     * @param positionOffset the position offset
     * @param positionOffsetPixels the position offset pixels
     */
    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
        // do nothing.
    }

    /**
     * Handle on page selected.
     * @param position the position
     */
    override fun onPageSelected(position: Int) {
        val view = findViewById<View>(R.id.wizard_next) as TextView
        val skipView = findViewById<View>(R.id.skip_wizard_activity) as TextView
        if (position == mSwiperControl!!.numViews - 1) {
            if (mbLaunchMain)
            {
                view.setText(R.string.wizard_end_start)
            }
            else{
                view.setText(R.string.wizard_end)
            }
            setSkipButtonVisibility(false, skipView)
        } else {
            view.setText(R.string.wizard_next)
            setSkipButtonVisibility(mbLaunchMain, skipView)
        }
    }

    /**
     * The on page scroll state changed handler.
     * @param state the state
     */
    override fun onPageScrollStateChanged(state: Int) {
        // do nothing.
    }

    /**
     * The Class WizardAdapter.
     */
    protected inner class WizardAdapter
    /**
     * Instantiates a new wizard adapter.
     * @param wizardTitles
     * @param wizardTitlesColors
     * @param wizardStrings
     */
    (private val mWizardMainTitles: Array<CharSequence>, private val mWizardTitles: Array<CharSequence>, private val mWizardTitlesColors: IntArray,
     /** The wizard strings.  */
     private val mWizardStrings: Array<CharSequence>) : PagerAdapter() {

        /**
         * Gets the count.
         * @return the count
         */
        override fun getCount(): Int {
            return mWizardStrings.size
        }

        /**
         * Destroy item.
         * @param container the container
         * @param position the position
         * @param object the object
         */
        override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
            container.removeView(`object` as View)
        }

        /**
         * Instantiate item.
         * @param container the container
         * @param position the position
         * @return the object
         */
        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            val view = WizardView(applicationContext, mWizardMainTitles[position], mWizardTitles[position], mWizardTitlesColors[position], mWizardStrings[position], position)
            if (view.parent == null) {
                container.addView(view)
            }
            return view
        }

        /**
         * Checks if is view from object.
         * @param view the view
         * @param object the object
         * @return true, if is view from object
         */
        override fun isViewFromObject(view: View, `object`: Any): Boolean {
            return view === `object`
        }
    }


    override fun onBackPressed() {
        super.onBackPressed()
    }

    /**
     * The Class WizardView.
     */
    protected inner class WizardView
    /**
     * Instantiates a new wizard view.
     * @param context the context
     */
    (context: Context) : LinearLayout(context) {

        /**
         * Instantiates a new wizard view.
         * @param context the context
         * @param text the text
         * @param number the number
         */
        constructor(context: Context, mainTitle: CharSequence, title: CharSequence, wizardTitleColor: Int, text: CharSequence, number: Int) : this(context) {

            val vi = getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            vi.inflate(R.layout.wizard_view, this, true)
            val wizard_maintitle = findViewById<View>(R.id.wizard_maintitle) as TextView
            val wizard_title = findViewById<View>(R.id.wizard_title) as TextView
            val wizard_text = findViewById<View>(R.id.wizard_text) as TextView
            val wizard_image = findViewById<View>(R.id.wizard_image) as ImageView

            wizard_title.text = title
            wizard_title.setTextColor(wizardTitleColor)

            val styledText = mSpanTokensHelper.setSpanBetweenTokens(text, "##", TextAppearanceSpan(getContext(), R.style.OnBordingHeaderText))
            wizard_text.text = styledText

            val imageResource = getImageResourceByNumber(number)
            if (imageResource != -1) {
                try {
                    wizard_image.setImageResource(imageResource)
                } catch (e: OutOfMemoryError) {
                    Log.e(LOG_TAG, "OutOfMemoryError in WizardView()", e)
                }

            }

            wizard_maintitle.text = mainTitle
        }

        /**
         * Gets the image resource by number.
         * @param number the number
         * @return the image resource by number
         */
        protected fun getImageResourceByNumber(number: Int): Int {
            return resources.getIdentifier(String.format("wizard_image_%d", number), "drawable", packageName)
        }
    }

    /**
     *
     * java.lang.String[], int[])
     */
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        var notGrantedAllPermissions = false
        for (grant in grantResults) {
            if (grant != PackageManager.PERMISSION_GRANTED) {
                notGrantedAllPermissions = true
                break
            }
        }
        if (!notGrantedAllPermissions) {
            val intent = Intent(this, (application as TheApplication).getMainActivity())
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }
    }

    /**
     * @param skipButtonVisibility
     * @param skipTextView
     */
    private fun setSkipButtonVisibility(skipButtonVisibility: Boolean, skipTextView: TextView?) {
        if (skipTextView != null) {
            skipTextView.visibility = if (skipButtonVisibility) View.VISIBLE else View.GONE
        }
    }

    internal fun termsOfServices() {
        val intent = Intent(this, TermsOfService::class.java)
        intent.putExtra(TermsOfService.INTENT_PARAM_ACCEPT_BUTTON, true)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_HISTORY
        startActivity(intent)
    }

    companion object {


        private val LOG_TAG = "WizardActivity"

        const val EXTRA_LAUNCH_MAINACTIVITY = "EXTRA_LAUNCH_MAINACTIVITY"
    }
}
