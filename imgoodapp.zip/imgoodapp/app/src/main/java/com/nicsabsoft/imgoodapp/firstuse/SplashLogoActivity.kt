/*
 * Copyright 2019 nicsabsoft, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * nicsabsoft, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with nicsabsoft.
 */
package com.nicsabsoft.imgoodapp.firstuse

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.util.Log.d
import android.view.Window

import com.nicsabsoft.imgoodapp.Constants
import com.nicsabsoft.imgoodapp.R
import com.nicsabsoft.imgoodapp.TheApplication
import com.nicsabsoft.imgoodapp.utils.MySharePreferences
import java.util.logging.Level


/**
 * The Class SplashLogoActivity.
 */
class SplashLogoActivity : AppCompatActivity() {

    /** The display length short.  */
    private val DISPLAY_LENGTH_SHORT = 200

    /** The m display length.  */
    private val mDisplayLength = DISPLAY_LENGTH_SHORT

    /** The run activity.  */
    private var runActivity: Runnable? = null

    /** The m handler.  */
    private val mHandler = Handler()

    /** The m MySharePreferences.  */
    private var mMySharePreferences: MySharePreferences? = null

    /**
     *
     */
    @SuppressLint("MissingSuperCall")
    public override fun onCreate(savedInstanceState: Bundle?) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        super.onCreate(savedInstanceState)
        Log.d( LOG_TAG, "onCreate()")

        mMySharePreferences = (application as TheApplication).mySharePreferences

        // Need to set force in case if app crashed
        cancelOldNotifications()

        setContentView(R.layout.splashscreen_connecting)

        checkingInstallSharePreference()

    }


    // Starts the connecting activity
    // Needed to extract this into a method, since it needs to
    // be called also when we receive a new intent from the SSO observer

    /**
     * Start connecting.
     * @param displayLength the display length
     */
    private fun startConnecting(displayLength: Int) {


        runActivity = startMainActivity()

        mHandler.removeCallbacks(runActivity) /* make sure that run Activity hasn't been already dispatched */
        mHandler.postDelayed(runActivity, displayLength.toLong())
        Log.d(LOG_TAG, "Posted delayed Connecting activity")
    }

    private fun startMainActivity(): Runnable {
        return Runnable {
            Log.d(LOG_TAG, "startMainActivity().runActivity.run(): ")
            val mainIntent = Intent(this@SplashLogoActivity, SplashConnectingActivity::class.java)
            mainIntent.action = Intent.ACTION_MAIN
            this@SplashLogoActivity.startActivity(mainIntent)
            overridePendingTransition(0, 0)
            this@SplashLogoActivity.finish()
            Log.d(LOG_TAG, "Connecting activity set to start")
        }
    }

    /**
     * Checking install share preference.
     */
    private fun checkingInstallSharePreference() {
        val sharedPreferences = mMySharePreferences!!.sharedPreferences
        val isInstall = sharedPreferences.getBoolean(Constants.FIRST_TIME_INSTALL, false)
        if (!isInstall) {
            saveInstallVariable()

            val intent: Intent
            intent = Intent(getIntentAction(WizardGetStartedActivity.INTENT_ACTION_WIZARD_GET_STARTED))
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            intent.setPackage(packageName)
            startActivity(intent)
            finish()
        } else {
            startConnecting(mDisplayLength)
        }
    }

    /**
     * Gets the package specific action for action suffix
     * @param actionSuffix
     * @return
     */
    private fun getIntentAction(actionSuffix: String): String {
        return String.format("%s%s", packageName, actionSuffix)
    }

    /**
     * Save install variable.
     */
    private fun saveInstallVariable() {
        mMySharePreferences!!.saveBooleanPreference(Constants.FIRST_TIME_INSTALL, true)
    }

    private fun cancelOldNotifications() {}

    companion object {

        /** The Constant LOG_TAG.  */
        private val LOG_TAG = SplashLogoActivity::class.java.simpleName
    }


}
