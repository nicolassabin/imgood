package com.nicsabsoft.imgoodapp

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.os.Build

import com.nicsabsoft.imgoodapp.utils.MySharePreferences
import com.nicsabsoft.imgoodapp.utils.NotificationFactory
import com.nicsabsoft.imgoodapp.widgets.MyAppCompatActivity


/**
 * Created by ns on 10/05/2017.
 */
class TheApplication : Application() {

    /**
     * get MySharePreferences.
     * @return MySharePreferences
     */
    var mySharePreferences: MySharePreferences? = null
        private set
    /**
     * get mNotificationFactory.
     * @return mNotificationFactory
     */
    var notificationFactory: NotificationFactory? = null
        private set

    /**
     * On create.
     */
    override fun onCreate() {
        super.onCreate()
        mySharePreferences = MySharePreferences(this, TheApplication)
        notificationFactory = NotificationFactory(this, this.resources.getString(R.string.notif_channel_id))
        notificationFactory!!.init()
    }

    /**
     * On terminate.
     */
    override fun onTerminate() {

        super.onTerminate()
    }

    /**
     * Show message notification.
     * @param id the id
     * @param text the text
     */
    fun showMessageNotification(id: Int, text: String) {
        showMessageNotification(id, this.getText(R.string.app_name), text)
    }


    /**
     * Show message notification for service.
     * @param id the id
     * @param text the text
     * @param intent the intent
     */
    fun showServiceMessageNotification(id: Int, text: String, intent: Intent) {
        showMessageNotification(id, this.getText(R.string.app_name), text, PendingIntent.getService(this, 0, intent, 0))
    }

    /**
     * Cancel notification.
     * @param notificationId the notification id
     */
    fun cancelNotification(notificationId: Int) {
        val notificationManager = this.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(notificationId)
    }

    /**
     * Show message notification.
     * @param id the id
     * @param title the title
     * @param text the text
     */
    private fun showMessageNotification(id: Int, title: CharSequence, text: String) {
        val intent = Intent(this.applicationContext, getMainActivity())
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        showMessageNotification(id, title, text, PendingIntent.getActivity(this, 0, intent,
                0))
    }


    /**
     * Show message notification.
     * @param id the id
     * @param title the title
     * @param text the text
     * @param pendingIntent the pendingIntent
     */
    private fun showMessageNotification(id: Int, title: CharSequence, text: String, pendingIntent: PendingIntent) {
        val notification = notificationFactory!!.createGenericNotification(text,
                System.currentTimeMillis(), Notification.FLAG_AUTO_CANCEL)

        notification.setLatestEventInfo(this, title, text, pendingIntent)
        notification.notification!!.contentIntent = pendingIntent
        (this.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, notification.notification)

    }

    fun getMainActivity() : Class<MainActivity> {
        if (resources.getBoolean(R.bool.all_in_one_screen))
        {
            return MainAndSettingsActivity::class.java as Class<MainActivity>
        }
        else
        {
            return MainActivity::class.java
        }
    }

    companion object {

        /** The Constant MESSAGES_NOTIFICATION_ID.  */
        val MESSAGES_NOTIFICATION_ID = 1

        /** First Marketing carousel.  */
        private val TheApplication = "ImgoodApplication"
    }

}
