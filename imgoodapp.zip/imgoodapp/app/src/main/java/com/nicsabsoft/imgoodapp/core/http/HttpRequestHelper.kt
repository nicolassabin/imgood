package com.nicsabsoft.imgoodapp.core.http

import android.content.Context
import android.util.Base64
import android.util.Log
import com.nicsabsoft.imgoodapp.R
import com.nicsabsoft.imgoodapp.core.utils.DeviceDetails
import com.nicsabsoft.imgoodapp.core.utils.NetworkTools
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.lang.Exception
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * The Class DeviceDetails.
 */
class HttpRequestHelper(private val mContext: Context, private val mServerUrl: String) {

    companion object {

        private const val LOG_TAG = "HttpRequestHelper";

        /** The Constant HEADER_CLIENT_APPLICATION_IDENTIFIER.  */
        private val HEADER_CLIENT_APPLICATION_IDENTIFIER = "w-application-identifier"

        /** The Constant HEADER_CLIENT_AUTH.  */
        private val HEADER_CLIENT_AUTH = "authorization"

        /** The Constant HEADER_CLIENT_USER_NAME.  */
        private val HEADER_CLIENT_USER_NAME = "user_email"

        /** The Constant HEADER_CLIENT_USER_PSW.  */
        private val HEADER_CLIENT_USER_PSW = "user_password"

        /** The Constant HEADER_CLIENT_CONTENT_TYPE.  */
        private val HEADER_CLIENT_CONTENT_TYPE = "Content-Type"

    }

    fun postRequestAlert(emailFromAdr: String, emailText:String, emailSubject: String, emailToAdr: String):Int {

        Log.d(LOG_TAG, "postRequestAlert -> emailText " + emailText +
                " emailSubject " + emailSubject + " emailAdr " + emailToAdr)
        val jsonobj = JSONObject()

        jsonobj.put("From", emailFromAdr)
        jsonobj.put("To", emailToAdr)
        jsonobj.put("Subject", emailSubject)
        jsonobj.put("Text", emailText)

        return sendPostRequest(mServerUrl + "/sendAlert/", mContext.resources.getString(R.string.httpus),
                mContext.resources.getString(R.string.httpp), "", jsonobj.toString())
    }


    fun sendPostRequest(url:String, userName: String, password: String, reqParam: String, body: String):Int {

        Log.d(LOG_TAG, "sendPostRequest -> url " + url)

        if (NetworkTools.isNetworkAvailable(mContext)){

            if (!url.isEmpty())
            {
                val mURL = URL(url+reqParam)

                try{
                    with(mURL.openConnection() as HttpURLConnection) {
                        // optional default is GET
                        requestMethod = "POST"

                        val deviceDetails = DeviceDetails(mContext)
                        val sHeaderAppId = deviceDetails.appId
                        if (!sHeaderAppId.isEmpty())
                        {
                            setRequestProperty(HEADER_CLIENT_APPLICATION_IDENTIFIER, Base64.encodeToString(deviceDetails.appId.toByteArray(), Base64.DEFAULT))
                        }

                        if (!userName.isEmpty() && !password.isEmpty())
                        {
                            setRequestProperty(HEADER_CLIENT_USER_NAME, Base64.encodeToString(userName.toByteArray(), Base64.DEFAULT))
                            setRequestProperty(HEADER_CLIENT_USER_PSW, Base64.encodeToString(password.toByteArray(), Base64.DEFAULT))
                            setRequestProperty(HEADER_CLIENT_AUTH, Base64.encodeToString((userName + ":" +password).toByteArray(), Base64.DEFAULT))
                        }

                        if (body.isNotEmpty())
                        {
                            setRequestProperty(HEADER_CLIENT_CONTENT_TYPE, "application/json; charset=utf-8")
                        }

                        val wr = OutputStreamWriter(getOutputStream())
                        // body
                        if (!body.isEmpty())
                        {
                            wr.write( body )
                        }

                        wr.flush()

                        Log.d(LOG_TAG,"sendPostRequest URL : $url" +" Response Code : $responseCode")

                        BufferedReader(InputStreamReader(inputStream)).use {
                            val response = StringBuffer()

                            var inputLine = it.readLine()
                            while (inputLine != null) {
                                response.append(inputLine)
                                inputLine = it.readLine()
                            }
                            it.close()
                            Log.d(LOG_TAG,"Response : $response")
                        }

                        return responseCode
                    }
                }
                catch (e: Exception) {
                    Log.e(LOG_TAG,"sendPostRequest Exception", e)
                }

            }
            else
            {
                Log.d(LOG_TAG,"sendPostRequest invalid url")
            }
        }
        else
        {
            Log.d(LOG_TAG,"sendPostRequest no network")
        }

        return 403
    }
}
