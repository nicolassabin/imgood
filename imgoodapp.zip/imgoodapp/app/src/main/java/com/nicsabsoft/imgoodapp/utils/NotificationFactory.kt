/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.nicsabsoft.imgoodapp.utils

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import android.support.v4.app.NotificationCompat
import android.support.v4.content.ContextCompat
import android.widget.RemoteViews

import com.nicsabsoft.imgoodapp.R

import java.text.SimpleDateFormat
import java.util.Calendar


/**
 * A factory for creating Notification objects.
 */
/**
 * Instantiates a new notification factory.
 */
class NotificationFactory(private val mContext: Context, private val mChannelId: String) {

    fun init(){
        createNotificationChannel()
    }


    /**
     * Creates a new Notification object.
     * @param tickerText the ticker text
     * @param when the when
     * @param flag the flag
     * @param icon the icon - if we don't want to use the default notification icons.
     * @return the notification wrapper
     */
    @JvmOverloads
    fun createGenericNotification(tickerText: CharSequence,
                                  whenT: Long = System.currentTimeMillis(), flag: Int = Notification.FLAG_AUTO_CANCEL, icon: Int = -1): NotificationWrapper {
        val builder = NotificationCompat.Builder(mContext, mChannelId)
        if (icon < 0) {
            setSmallIcon(builder)
        } else {
            builder.setSmallIcon(icon)
        }
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder.color = ContextCompat.getColor(mContext, R.color.notification_color)

            val contentView = RemoteViews(mContext.packageName, R.layout.generic_notification)
            contentView.setImageViewResource(R.id.generic_notification_image, NotificationFactory.progressSmallIcon)
            contentView.setTextViewText(R.id.generic_notification_big_text, tickerText)
            if (whenT > -1) {
                contentView.setTextViewText(R.id.generic_notification_when, convertLongTime(whenT, "hh:mm aa"))
            }
            builder.setContent(contentView)
        }*/
        if (flag == Notification.FLAG_AUTO_CANCEL)
            builder.setAutoCancel(true)
        builder.setContentText(tickerText)
        builder.setContentTitle(tickerText)
        builder.setWhen(whenT)
        builder.setLocalOnly(true)
        val notification = builder.build()
        notification.flags = notification.flags or flag
        return NotificationWrapper(builder, notification)
    }

    private fun createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = mContext.resources.getString(R.string.app_name)
            val descriptionText = mContext.resources.getString(R.string.notif_channel_description)
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(mChannelId, name, importance).apply {
                description = descriptionText
            }
            // Register the channel with the system
            val notificationManager: NotificationManager =
                    mContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * Creates a new Notification object.
     * @return the notification wrapper
     */
    fun createCancelNotification(): NotificationWrapper {
        val cancelText = mContext.getString(R.string.action_cancelled)
        return createGenericNotification(cancelText)
    }

    /**
     * The Class NotificationWrapper.
     */
    class NotificationWrapper
    /**
     * Instantiates a new notification wrapper.
     * @param builder the builder
     * @param notification the notification
     */
    (
            /** The m builder.  */
            private val mBuilder: NotificationCompat.Builder, notification: Notification) {

        /** The m notification.  */
        /**
         * Gets the notification.
         * @return the notification
         */
        var notification: Notification? = null
            private set

        init {
            this.notification = notification
        }

        /**
         * Sets the latest event info.
         * @param context the context
         * @param contentTitle the content title
         * @param contentText the content text
         * @param contentIntent the content intent
         */
        fun setLatestEventInfo(context: Context, contentTitle: CharSequence, contentText: CharSequence,
                               contentIntent: PendingIntent) {
            mBuilder.setContentTitle(contentTitle)
            mBuilder.setContentText(contentText)
            mBuilder.setContentIntent(contentIntent)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mBuilder.color = ContextCompat.getColor(context, R.color.notification_color)

                val contentView = RemoteViews(context.packageName, R.layout.generic_notification)
                contentView.setTextViewText(R.id.generic_notification_big_text, contentTitle)
                contentView.setTextViewText(R.id.generic_notification_small_text, contentText)
                mBuilder.setContent(contentView)
            }
            notification = mBuilder.build()
        }
    }

    @SuppressLint("SimpleDateFormat")
    fun convertLongTime(millis: Long, timeFormat: String): String {
        val formatter = SimpleDateFormat(timeFormat)
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = millis
        return formatter.format(calendar.time)
    }

    companion object {


        /**
         * Returns the progress notification icon.
         * @return the progress notification icon.
         */
        val progressSmallIcon: Int
            get() = R.drawable.ic_notification

        /**
         * Returns the notification icon.
         * @return the notification icon.
         */
        val smallIcon: Int
            get() = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                R.drawable.ic_notification
            } else R.drawable.ic_notification

        /**
         * Sets the notification icon on the notification builder object.
         * Will either be ic_launcher_white for new versions of android or ic_launcher for older versions.
         * @param notifyBuilder the notification builder object.
         * @return the notification builder so method calls can be chained.
         */
        fun setSmallIcon(notifyBuilder: NotificationCompat.Builder): NotificationCompat.Builder {
            notifyBuilder.setSmallIcon(smallIcon)
            return notifyBuilder
        }
    }

}
