/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.nicsabsoft.imgoodapp


/**
 * The Interface Constants.
 */
interface Constants {
    companion object {


        /**
         * The user login already.
         */
        val FIRST_TIME_INSTALL = "FIRST_TIME_INSTALL"

        const val MONDAY            = "MONDAY"
        const val THUESDAY          = "THUESDAY"
        const val WEDNESDAY         = "WEDNESDAY"
        const val THURSDAY          = "THURSDAY"
        const val FRIDAY            = "FRIDAY"
        const val SATURDAY          = "SATURDAY"
        const val SUNDAY            = "SUNDAY"

        const val TIME_START        = "TIME_START"
        const val TIME_MIDDLE       = "TIME_MIDDLE"
        const val TIME_MIDDLE2      = "TIME_MIDDLE2"
        const val TIME_END          = "TIME_END"
        const val TIME_START_POS    = "TIME_START_POS"
        const val TIME_MIDDLE_POS   = "TIME_MIDDLE_POS"
        const val TIME_MIDDLE2_POS  = "TIME_MIDDLE2_POS"
        const val TIME_END_POS      = "TIME_END_POS"

        const val NOTIF_ACTION      = "NOTIF_ACTION"
        const val SMS_PHONENUMBERS  = "SMS_PHONENUMBERS"
        const val NOTIF_ISSUE       = "NOTIF_ISSUE"
        const val EMAILS_ADR        = "EMAILS_ADR"

        const val DEFAULT_ITEM_SELECTED = 4;
    }

}



