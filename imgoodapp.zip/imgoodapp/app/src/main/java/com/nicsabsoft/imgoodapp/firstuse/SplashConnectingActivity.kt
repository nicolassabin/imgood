/*
 * Copyright 2019 nicsabsoft, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * nicsabsoft, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with nicsabsoft.
 */
package com.nicsabsoft.imgoodapp.firstuse

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import com.nicsabsoft.imgoodapp.Constants
import com.nicsabsoft.imgoodapp.R
import com.nicsabsoft.imgoodapp.TheApplication
import kotlinx.android.synthetic.main.splashscreen_connecting.*



/**
 * The Class SplashConnectingActivity.
 */
class SplashConnectingActivity : AppCompatActivity(), Constants {


    /** The display length short.  */
    private val DISPLAY_LENGTH_SHORT = 200

    /** The log tag.  */
    private val LOG_TAG = "SplashActivity"

    /**
     *
     */
    @SuppressLint("MissingSuperCall")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d( LOG_TAG, "> onCreate(), action: " + intent.action!!)

        setContentView(R.layout.splashscreen_connecting)
        startProgress()

        Log.d( LOG_TAG, "< onCreate()")
        this.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER
    }

    /* Handles close of activity. */

    /**
     *
     */
    public override fun onDestroy() {
        super.onDestroy()

        this.progressSplash!!.visibility = View.GONE
    }

    /**
     * Authenticate user.
     */
    @Synchronized
    private fun startProgress() {
        Log.d( LOG_TAG, "startProgress start")

        this.progressSplash!!.visibility = View.VISIBLE
        try {
            Thread.sleep(DISPLAY_LENGTH_SHORT.toLong())
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }

        startMainActivity()
    }

    /**
     * Continue startup flow.
     */
    private fun startMainActivity() {
        Log.d( LOG_TAG, "startMainActivity(), check if first launch")
        val intent = Intent(this, (application as TheApplication).getMainActivity())
        startActivity(intent)

        finish()

    }


}
