
package com.nicsabsoft.imgoodapp.core.utils

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.provider.Settings
import android.provider.Settings.Secure
import android.telephony.TelephonyManager
import android.text.TextUtils
import android.util.Log
import com.nicsabsoft.imgoodapp.R


import java.util.Locale

/**
 * The Class DeviceDetails.
 */
class DeviceDetails(private val mContext: Context) {

    /**
     * The x_application_identifier.
     */
    protected val application_user_agent = "imgood/%1\$s (%2\$s; %3\$s) %4\$s"

    /**
     * Gets the id.
     * @return the id
     */
    val id: String
        get() {
            val result = androidId

            Log.d(TAG, "getId: returning id $result")
            return result
        }

    /**
     * Gets the app id.
     * @return the app id
     */
    val appId: String
        get() {
            val result = generateUserAgent(mContext)

            Log.d(TAG, "getAppId: returning id $result")
            return result
        }

    /**
     * Gets the android id.
     * @return the android id
     */
    private val androidId: String
        get() = Secure.getString(mContext.contentResolver, Secure.ANDROID_ID)

    /**
     * Gets the name.
     * @return the name
     */
    // There is no "best combination" for all devices.
    // Manufacturer + Model is "somewhat friendly" on "some devices"
    // If the OEM included the manufacturer string in the model string,
    // let's just use the model string alone (like "HTC Desire")
    // we make sure it starts with an upparcase char
    // ..otherwise let's use the manufacturer + model
    // it may result in strings like "motorola Milestone" and "HTC ADR6400L"
    // we make sure both components start with an upparcase char
    val name: String?
        get() {
            val result: String?

            if (Build.MODEL.toUpperCase().contains(Build.MANUFACTURER.toUpperCase())) {
                result = firstCharToUpper(Build.MODEL)
            } else {
                result = String.format("%s %s", firstCharToUpper(Build.MANUFACTURER), firstCharToUpper(Build.MODEL))
            }

            Log.d(TAG, "name = " + result!!)

            return result
        }

    /**
     * Gets the DeviceIdentifier.
     * @return the DeviceIdentifier
     */
    /*val deviceIdentifier: String
        get() = getVersionName(mContext) + "|" + getDeviceId(mContext) + "|" + mContext.packageName + "|" + deviceName
    */

    // returns the 3 digit MCC as an integer OR -1
    /**
     * Gets the mcc.
     * @return the mcc
     */
    val mcc: Int
        get() {
            var result = -1
            val telMan = mContext.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            try {
                val operator = telMan.simOperator
                if (!TextUtils.isEmpty(operator) && operator.length >= MCC_LENGTH) {
                    val mcc = operator.substring(0, MCC_LENGTH)
                    try {
                        result = Integer.valueOf(mcc)
                    } catch (e: NumberFormatException) {
                        Log.e(TAG, "exception ", e)
                    }

                }
            } catch (e: Exception) {
                Log.e(TAG, "getMcc: exception ", e)
            }

            Log.d(TAG, "getMcc => $result")
            return result
        }

    /**
     * Creates an `Accept-Language` header value based on the actual local settings on the device (like
     * `en-IE` or `en`).
     * @return The `Accept-Language` header value
     * @throws CoreException the cloud sdk exception
     */
    // This is not expected to happen, but let's handle this case anyways
    val acceptLanguageHeaderValue: String
        get() {
            val locale = Locale.getDefault()
            val language = locale.language
            val country = locale.country
            val hasLanguage = !TextUtils.isEmpty(language)
            val hasCountry = !TextUtils.isEmpty(country)

            var result: String? = null

            if (hasLanguage && hasCountry) {
                result = String.format("%s-%s", language, country)
            } else if (hasLanguage) {
                result = language
            }

            Log.d(TAG, "getAcceptHeaderValue() returns: " + result!!)

            return result
        }

    /**
     * Generate user agent.
     *
     * @return the string
     */
    private fun generateUserAgent(context: Context): String {
        // Version
        var version: String? = null
        try {
            val pkgManager = context.packageManager
            val pi = pkgManager.getPackageInfo(context.packageName, 0)
            version = pi.versionName // 0 - no flags
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e(TAG, "generateUserAgent = ", e)
        }

        // Locale
        val locale = Locale.getDefault().toString()

        // OS Version
        val osVersion = StringBuilder("Android")
        // removed
        osVersion.append(" ").append(Build.VERSION.RELEASE)

        // Device
        val device = StringBuilder()
        device.append(android.os.Build.MANUFACTURER)
        device.append("/")

        var detail: String? = android.os.Build.MODEL
        if (detail != null && detail.length == 0) {
            detail = android.os.Build.DEVICE
            if (detail != null && detail.length == 0) {
                detail = android.os.Build.PRODUCT
            }
        }
        device.append(detail)

        var ua = String.format(application_user_agent, version, locale, osVersion, device)
        //TODO shall be removed later
        ua = context.resources.getString(R.string.app_id)
        return ua
    }

    /*private fun getDeviceId(a_Context: Context?): String? {
        // set as null for tablet or emulator
        var ret: String? = null

        if (a_Context == null) {
            return ret
        }

        // should be changed later on server side.
        // that allows to map with the deviceAgent created by server at the first carddav sync

        val telManager = a_Context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        if (telManager != null) {
            val isEmulator = android.os.Build.MODEL != null && (android.os.Build.MODEL.equals("google_sdk", ignoreCase = true) || android.os.Build.MODEL
                    .equals("sdk", ignoreCase = true))

            if (!isEmulator && !isTablet(a_Context)) {
                try {
                    val sImei = telManager.deviceId
                    if (!TextUtils.isEmpty(sImei)) {
                        ret = IMEI_PREFIX + sImei
                        return ret
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "getDeviceId: exception ", e)
                }

            } else if (isEmulator) {
                val tempBuffer = StringBuilder()
                tempBuffer.append(deviceName)
                tempBuffer.append("_")
                tempBuffer.append(java.lang.Long.toString(System.currentTimeMillis()))
                ret = Integer.toString(tempBuffer.toString().hashCode())
            } else {
                ret = DEVICEID_PREFIX + Settings.Secure.getString(a_Context.contentResolver, Settings.Secure.ANDROID_ID)
            }
        } else {
            ret = DEVICEID_PREFIX + Settings.Secure.getString(a_Context.contentResolver, Settings.Secure.ANDROID_ID)
        }

        return ret
    }*/

    companion object {

        /** The Constant TAG.  */
        private val TAG = "DeviceDetails"

        /** The Constant VERSION.  */
        val VERSION = "v1"

        /** The Constant IMEI_PREFIX.  */
        private val IMEI_PREFIX = "imei_"
        /** The Constant DEVICEID_PREFIX.  */
        private val DEVICEID_PREFIX = "mac_"

        /** The Constant MCC_LENGTH.  */
        private val MCC_LENGTH = 3

        /**
         * Greturn if device is a tablet.
         * @return true if tablet
         */
        fun isTablet(a_Context: Context): Boolean {
            return isTabletConfiguration(a_Context)
        }


        /**
         * Greturn if device is an emulator.
         * @return true if emulator
         */
        val isEmulator: Boolean
            get() {
                val model = Build.MODEL
                Log.d(TAG, "model=$model")
                val product = Build.PRODUCT
                Log.d(TAG, "product=" + product!!)
                var isEmulator = product == "sdk" || product.contains("_sdk") || product.contains("sdk_")
                Log.d(TAG, "isEmulator=$isEmulator")
                return isEmulator
            }

        private val deviceName: String
            get() {
                val manufacturer = filter(android.os.Build.BRAND)
                val product = filter(android.os.Build.PRODUCT)
                val model = filter(android.os.Build.MODEL)

                return manufacturer + "_" + product + "_" + model

            }

        /**
         * Get the versionname from the manifest
         *
         * @return versionname
         */
        private fun getVersionName(): String {
            return VERSION
        }

        private fun filter(a_Value: String?): String? {
            var result: String

            if (a_Value == null) {
                return null
            }

            result = a_Value.replace('.', '_')
            result = result.replace(' ', '_')
            result = result.replace('-', '_')

            return result.toLowerCase()
        }


        private fun isTabletConfiguration(context: Context): Boolean {
            try {
                val config = context.resources.configuration
                if (config.smallestScreenWidthDp >= 600) {
                    return true
                }
            } catch (ex: ClassCastException) {
            }

            return false
        }

        /**
         * First char to upper.
         * @param s the s
         * @return the string
         */
        private fun firstCharToUpper(s: String): String? {
            return if (TextUtils.isEmpty(s)) s else Character.toUpperCase(s[0]) + s.substring(1)
        }
    }


}
