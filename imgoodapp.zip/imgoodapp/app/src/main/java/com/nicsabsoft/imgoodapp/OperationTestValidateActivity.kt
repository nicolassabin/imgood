package com.nicsabsoft.imgoodapp



import android.os.Bundle
import android.util.Log
import com.nicsabsoft.imgoodapp.core.alarm.AlarmScenario
import kotlinx.android.synthetic.main.activity_operationtest.*


class OperationTestValidateActivity : OperationValidateActivity() {

    companion object {

        private const val LOG_TAG = "OpeTActivity"

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d( LOG_TAG, "onCreate")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_operationtest)

        mAlarmScenario = AlarmScenario(this, this.imageOperationTest, this)
        mAlarmScenario?.init("test_alarmstep")

        val actionBar = supportActionBar
        actionBar!!.setHomeButtonEnabled(true)
        actionBar.setDisplayHomeAsUpEnabled(true)

        mProgressBar = this.progressBar_cyclicTest

        this.buttonTestOperationValidate?.setOnClickListener {
            Log.d( LOG_TAG, "buttonTestOperationValidate setOnClickListener")
            validateOperation(false)
        }

        this.buttonTestSimulateAlert?.setOnClickListener {
            Log.d( LOG_TAG, "buttonTestSimulateAlert setOnClickListener")
            // stop the alarm and send the email
            notValidateOperation(false)
        }

    }
    override fun onBackPressed() {
        Log.d( LOG_TAG, "onBackPressed")

        mbValidationFromBack = false
        super.onBackPressed()
    }

    override fun notifyEndAlarmScenario() {
        Log.d( LOG_TAG, "notifyEndAlarmScenario")
        
    }

}

