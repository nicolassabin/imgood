package com.nicsabsoft.imgoodapp


import android.app.AlertDialog
import android.content.*
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.util.Log
import android.view.View
import com.nicsabsoft.imgoodapp.core.AppService
import com.nicsabsoft.imgoodapp.firstuse.WizardActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.text.SimpleDateFormat
import java.util.*
import android.view.Menu
import android.view.MenuItem


open class MainActivity : AppBasedActivity() {

    companion object {

        private const val LOG_TAG = "MainActivity"

        protected const val REQUEST_CODE_HELP       = 1
        protected const val REQUEST_CODE_SETTINGS   = 2
        protected const val REQUEST_CODE_IMMGOOD   = 3

    }

    private val mServerBCReceiver by lazy { makeBroadcastReceiver() }

    protected var mbSaveAndStartService: Boolean = true

    open fun getLayoutId(): Int{ return R.layout.activity_main}

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d( LOG_TAG, "onCreate")
        super.onCreate(savedInstanceState)
        setContentView(getLayoutId())

        mProgressBar = this.progressBar_cyclicMain

        this.imageButtonHelp.setOnClickListener {
            Log.d( LOG_TAG, "imageButtonHelp setOnClickListener")
            doHelp()

        }

        this.imageButtonSettings?.setOnClickListener {
            Log.d( LOG_TAG, "imageButtonSettings setOnClickListener")
            doSettings()
        }

        this.buttonSwitch.setOnClickListener {
            Log.d( LOG_TAG, "buttonSwitch setOnClickListener")
            if (this.buttonSwitch.isChecked) {
                saveDatas()
                startService()
            }
            else
            {
                this.buttonIMGood.isEnabled = false
                this.buttonIMNOTGood.isEnabled = false
                this@MainActivity.appstatus.setText(R.string.app_status_stopped)
                //this@MainActivity.appstatus.setTextColor(ContextCompat.getColor(this@MainActivity,R.color.textview_text_color))
                this@MainActivity.appstatus.setTextColor(ContextCompat.getColor(this@MainActivity,android.R.color.holo_red_dark))
                this@MainActivity.appstatus_alarm.text = ""
                stopService(Intent(applicationContext, AppService::class.java))
            }
        }

        this.buttonIMGood.setOnClickListener {
            Log.d( LOG_TAG, "buttonIMGood setOnClickListener")
            val intent = Intent(this@MainActivity, ImgoodActivity::class.java)
            startActivityForResult(intent, REQUEST_CODE_IMMGOOD)

        }

        this.buttonIMNOTGood.setOnClickListener {
            Log.d( LOG_TAG, "buttonIMNOTGood setOnClickListener")
            sendNotification(getString(R.string.message_confirmation_imnotgood_smstext),
                    getString(R.string.message_confirmation_imnotgood_text))

        }

        this.buttonStart.setOnClickListener {
            Log.d( LOG_TAG, "buttonStart setOnClickListener")
            saveDatas()
            startService()
        }

        this.buttonStop.setOnClickListener{
            Log.d( LOG_TAG, "buttonStop setOnClickListener")
            // If the service is not running then start it
            this.buttonSwitch.isChecked = true
            this.buttonStart.isEnabled = true
            this.buttonStop.isEnabled = false
            this.buttonIMGood.isEnabled = false
            this.buttonIMNOTGood.isEnabled = false
            this@MainActivity.appstatus.setText(R.string.app_status_stopped)
            this@MainActivity.appstatus.setTextColor(ContextCompat.getColor(this@MainActivity,android.R.color.holo_red_dark))
            this@MainActivity.appstatus_alarm.text = ""
            stopService(Intent(applicationContext, AppService::class.java))
        }

        if (resources.getBoolean(R.bool.enable_menu)){
            this.imageButtonHelp?.visibility = View.INVISIBLE
            this.imageButtonSettings?.visibility = View.INVISIBLE
        }

        registerReceiver(mServerBCReceiver, IntentFilter(AppService.INTENT_ACTION_APP_SERVICE_STARTED))

        if (!mMySharePreferences!!.notificationValid()){
            Log.d( LOG_TAG, "notificationValid not valid, redirect to the settings")
            // start the settings
            val builder = AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle)
            builder.setMessage(getString(R.string.settings_not_complete))
            builder.setCancelable(false)
            builder.setTitle(getString(R.string.settings_not_complete_title))
            builder.setPositiveButton(R.string.ok){ _, _ ->
                doSettings()
            }
            // Finally, make the alert dialog using builder
            val dialog: AlertDialog = builder.create()

            // Display the alert dialog on app interface
            dialog.show()


        }
    }

    private fun doSettings() {
        Log.d( LOG_TAG, "doSettings")
        mbSaveAndStartService = false
        val intent = Intent(this@MainActivity, SettingsActivity::class.java)
        startActivityForResult(intent, REQUEST_CODE_SETTINGS)
    }

    private fun doHelp() {
        Log.d( LOG_TAG, "doHelp")
        mbSaveAndStartService = false
        val intent = Intent(this@MainActivity, WizardActivity::class.java)
        intent.putExtra(WizardActivity.EXTRA_LAUNCH_MAINACTIVITY, false)
        startActivityForResult(intent, REQUEST_CODE_HELP)
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (resources.getBoolean(R.bool.enable_menu)){
            menuInflater.inflate(R.menu.app_menu, menu)
            return true
        }
        return false
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_settings -> {
                doSettings()
                return true
            }
            R.id.action_help -> {
                doHelp()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
    override fun onResume() {
        Log.d( LOG_TAG, "onResume")

        setTitle(R.string.app_name)
        super.onResume()
        this.buttonIMGood?.isEnabled = false
        this.buttonIMNOTGood?.isEnabled = false
        startService()

    }

    override fun onBackPressed() {
        Log.d( LOG_TAG, "onBackPressed")

        super.onBackPressed()
    }

    private fun startServiceIfNeeded(){
        if (!this.buttonStart.isEnabled || this.buttonSwitch.isChecked) // service is started, so restarted here to get new config
        {
            startService()
        }
    }
    override fun onPause() {
        Log.d( LOG_TAG, "onPause")

        if (mbSaveAndStartService)
        {
            startServiceIfNeeded()
        }

        super.onPause()

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        Log.d( LOG_TAG, "onActivityResult requestCode $requestCode")
        if (requestCode == REQUEST_CODE_HELP){
            mbSaveAndStartService = true
        } else if (requestCode == REQUEST_CODE_SETTINGS){
            mbSaveAndStartService = true
            this.buttonIMGood.isEnabled = mMySharePreferences!!.notificationValid()
            this.buttonIMNOTGood.isEnabled = mMySharePreferences!!.notificationValid()
            startServiceIfNeeded()
        }
        super.onActivityResult(requestCode, resultCode, data)
    }


    override fun onDestroy() {
        Log.d( LOG_TAG, "onDestroy")

        super.onDestroy()

        // 5
        try {
            unregisterReceiver(mServerBCReceiver)

        } catch (e: IllegalArgumentException) {
            Log.e(LOG_TAG, "unregisterReceiver exception", e)
        }
    }

    private fun startService()
    {
        Log.d( LOG_TAG, "startService")
        mProgressBar?.visibility = View.VISIBLE
        // Variable to hold service class name
        val serviceClass = AppService::class.java
        // Initialize a new Intent instance
        val intent = Intent(applicationContext, serviceClass)
        intent.setPackage(application.packageName)
        intent.putExtra(AppService.PARAM_ACTION, AppService.ACTION_SET_ALARM)
        intent.putExtra(AppService.EXTRA_SETALARM_NEXTDAY, false)
        startService(intent)
        /*mAsyncTaskService =
                object : AsyncTask<String, Void, Intent>() {

                    override fun onPreExecute() {
                        mProgressBar?.visibility = View.VISIBLE

                    }

                    override fun doInBackground(vararg params: String): Intent? {
                        // Variable to hold service class name
                        val serviceClass = AppService::class.java
                        // Initialize a new Intent instance
                        val intent = Intent(applicationContext, serviceClass)
                        intent.setPackage(application.packageName)
                        intent.putExtra(AppService.PARAM_ACTION, AppService.ACTION_SET_ALARM)
                        intent.putExtra(AppService.EXTRA_SETALARM_NEXTDAY, false)
                        startService(intent)
                        return intent
                    }

                    override fun onPostExecute(result: Intent) {
                    }
                }
        mAsyncTaskService?.execute()
        */
    }


    private fun makeBroadcastReceiver(): BroadcastReceiver {
        Log.d( LOG_TAG, "makeBroadcastReceiver")
        return object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent?) {
                Log.d( LOG_TAG, "onReceive " + intent?.action)
                var bServiceStarted = false
                if (intent?.action == AppService.INTENT_ACTION_APP_SERVICE_STARTED) {
                    Log.d( LOG_TAG, "makeBroadcastReceiver AppService started")
                    bServiceStarted = true
                }

                this@MainActivity.buttonStart.isEnabled = !bServiceStarted
                this@MainActivity.buttonStop.isEnabled = bServiceStarted
                this@MainActivity.buttonIMGood?.isEnabled = mMySharePreferences!!.notificationValid()
                this@MainActivity.buttonIMNOTGood?.isEnabled = mMySharePreferences!!.notificationValid()
                this@MainActivity.buttonSwitch.isChecked = bServiceStarted
                val strAppStatus : String
                if (bServiceStarted){
                    strAppStatus = getString(R.string.app_status_started)
                    this@MainActivity.appstatus.setTextColor(ContextCompat.getColor(this@MainActivity,R.color.textview_text_color))
                }
                else {
                    strAppStatus = getString(R.string.app_status_stopped)
                    this@MainActivity.appstatus.setTextColor(ContextCompat.getColor(this@MainActivity,android.R.color.holo_red_dark))
                }
                this@MainActivity.appstatus.text = strAppStatus

                // display next alarm
                if (intent!!.hasExtra(AppService.EXTRA_ALARM)) {
                    val lt = intent.extras[AppService.EXTRA_ALARM] as Long
                    if (lt > 0L) {
                        val dateFormat = SimpleDateFormat("E HH:mm")
                        Log.d(LOG_TAG, "Al setTimeCalendar currenttime " +
                                dateFormat.format(Date(lt)))

                        // display in UI
                        this@MainActivity.appstatus_alarm.text = (getString(R.string.app_next_alarm)
                                + dateFormat.format(Date(lt)))
                    }
                }

                mProgressBar?.visibility = View.GONE

            }
        }

    }

    open fun saveDatas() {}

}

