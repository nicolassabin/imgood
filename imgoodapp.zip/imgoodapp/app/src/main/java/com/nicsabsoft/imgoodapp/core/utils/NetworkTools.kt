package com.nicsabsoft.imgoodapp.core.utils

import android.content.Context
import android.net.ConnectivityManager
import android.util.Log


class NetworkTools (){

    companion object {

        private const val LOG_TAG = "NetworkTools";

        fun isNetworkAvailable(context : Context): Boolean {
            Log.d(LOG_TAG, "isNetworkAvailable")

            var connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            var bRet = false
            if (connectivityManager?.getActiveNetworkInfo() != null)
            {
                bRet = connectivityManager.getActiveNetworkInfo().isConnectedOrConnecting()
            }
            Log.d(LOG_TAG, "isNetworkAvailable bRet " + bRet)
            return bRet
        }
    }


}