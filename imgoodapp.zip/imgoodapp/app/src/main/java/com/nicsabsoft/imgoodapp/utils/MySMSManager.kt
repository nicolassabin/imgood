package com.nicsabsoft.imgoodapp.utils

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsManager
import android.util.Log
import java.util.*


class MySMSManager (private var mContext: Context){
    companion object {

        private val TAG = "MySMSManager"

        val SMS_SENT = "SMS_SENT"
    }

    fun notifyBySMS( phonenumbers: String, messageText: String): Boolean{
        Log.d(TAG, "notifyBySMS")

        // check value
        if (phonenumbers.isEmpty())
        {
            Log.d(TAG, "notifyBySMS phonenumbers.isEmpty")
            return false
        }

        if (messageText.isEmpty())
        {
            Log.d(TAG, "notifyBySMS messageText.isEmpty")
            return false
        }

        val sentPI = PendingIntent.getBroadcast(mContext, 0,
                Intent(SMS_SENT), 0)

        val smsManager = SmsManager.getDefault()

        val st = StringTokenizer(phonenumbers, ",")
        while (st.hasMoreTokens()){
            val ph = st.nextToken()
            Log.d(TAG, "notifyBySMS messageText to " + ph)
            try{
                smsManager.sendTextMessage(ph, null, messageText, sentPI, null)
            }
            catch (e: Exception){
                Log.e(TAG, "notifyBySMS exception", e)
                return false
            }

        }
        return true;

    }

}