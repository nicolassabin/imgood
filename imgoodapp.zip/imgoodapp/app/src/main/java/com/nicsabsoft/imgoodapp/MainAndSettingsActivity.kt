package com.nicsabsoft.imgoodapp


import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import com.nicsabsoft.imgoodapp.Constants.Companion.EMAILS_ADR
import com.nicsabsoft.imgoodapp.Constants.Companion.DEFAULT_ITEM_SELECTED
import com.nicsabsoft.imgoodapp.Constants.Companion.FRIDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.MONDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.NOTIF_ACTION
import com.nicsabsoft.imgoodapp.Constants.Companion.NOTIF_ISSUE
import com.nicsabsoft.imgoodapp.Constants.Companion.SATURDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.SMS_PHONENUMBERS
import com.nicsabsoft.imgoodapp.Constants.Companion.SUNDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.THUESDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.THURSDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_END
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_END_POS
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_MIDDLE
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_MIDDLE2
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_MIDDLE2_POS
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_MIDDLE_POS
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_START
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_START_POS
import com.nicsabsoft.imgoodapp.Constants.Companion.WEDNESDAY
import com.nicsabsoft.imgoodapp.core.utils.NetworkTools
import com.nicsabsoft.imgoodapp.utils.MySharePreferences
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_mainandsettings.*


class MainAndSettingsActivity : MainActivity() {

    companion object {

        private const val LOG_TAG = "MainSetActivity"

    }

    override fun getLayoutId(): Int{ return R.layout.activity_mainandsettings}

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d( LOG_TAG, "onCreate")
        super.onCreate(savedInstanceState)

        mProgressBar = this.progressBar_cyclicMainAndSettings

        this.spinner_timestart?.adapter = ArrayAdapter<String>(this,R.layout.spinner_item,
                this.resources.getStringArray(R.array.settings_timestart))

        this.spinner_timemiddle?.adapter = ArrayAdapter<String>(this,R.layout.spinner_item,
                this.resources.getStringArray(R.array.settings_timemiddle))

        this.spinner_timemiddle2?.adapter = ArrayAdapter<String>(this,R.layout.spinner_item,
                this.resources.getStringArray(R.array.settings_timemiddle2))

        this.spinner_timeend?.adapter = ArrayAdapter<String>(this,R.layout.spinner_item,
                this.resources.getStringArray(R.array.settings_timeend))

        this.buttonClose.setOnClickListener{
            Log.d( LOG_TAG, "buttonClose setOnClickListener")
            finish()
        }

        this.buttonTest.setOnClickListener{
            Log.d( LOG_TAG, "buttonTest setOnClickListener")
            val i = Intent(this, OperationTestValidateActivity::class.java)
            startActivity(i)
        }

        this.checkBoxActionNotif.setOnClickListener{
            Log.d( LOG_TAG, "checkBoxActionNotif setOnClickListener")
            this.smsphonenumbers.isEnabled = this.checkBoxActionNotif.isChecked
            enableButtonTest()
        }

        this.checkBoxAlertNotif.setOnClickListener{
            Log.d( LOG_TAG, "checkBoxAlertNotif setOnClickListener")
            this.alertemails.isEnabled = this.checkBoxAlertNotif.isChecked
            enableButtonTest()

        }

        this.smsphonenumbers.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
                Log.d( LOG_TAG, "smsphonenumbers setOnEditorActionListener")
                enableButtonTest()
            }
        })

        this.alertemails.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
                Log.d( LOG_TAG, "alertemails setOnEditorActionListener")
                enableButtonTest()
            }
        })

    }


    private fun enableButtonTest()
    {
        if (this.checkBoxActionNotif.isChecked || this.checkBoxAlertNotif.isChecked)
        {
            this.buttonTest.isEnabled = !this.smsphonenumbers.text.isEmpty() || !this.alertemails.text.isEmpty()
        }
        else
        {
            this.buttonTest.isEnabled = false
        }
    }
    override fun onResume() {
        Log.d( LOG_TAG, "onResume")

        super.onResume()

        // ask to continue the scanning or not
        loadDatas()
    }

    override fun onBackPressed() {
        Log.d( LOG_TAG, "onBackPressed")

        if (!checkValues())
            return

        super.onBackPressed()
    }

    override fun onPause() {
        Log.d( LOG_TAG, "onPause")

        if (mbSaveAndStartService)
        {
            saveDatas()
        }

        super.onPause()

    }

    override fun onDestroy() {
        Log.d( LOG_TAG, "onDestroy")

        super.onDestroy()

    }

    /**
     * @see MySharePreferences.getBooleanPreference
     */
    private fun checkValues(): Boolean {
        // check value
        // check 2 days are checked
        if (!this.checkBoxSaturday.isChecked && !this.checkBoxFriday.isChecked
                && !this.checkBoxMonday.isChecked && !this.checkBoxThursday.isChecked
                && !this.checkBoxThuesday.isChecked && !this.checkBoxSunday.isChecked
                && !this.checkBoxWednesday.isChecked)
        {
            Toast.makeText(this, R.string.empty_dayvalue, Toast.LENGTH_LONG).show()
            return false
        }

        if (this.checkBoxActionNotif.isChecked && this.smsphonenumbers.text.isEmpty()){
            Toast.makeText(this, R.string.empty_value, Toast.LENGTH_LONG).show()
            this.smsphonenumbers.requestFocus()
            return false
        }
        if (this.checkBoxAlertNotif.isChecked && this.alertemails.text.isEmpty()){
            Toast.makeText(this, R.string.empty_value, Toast.LENGTH_LONG).show()
            this.alertemails.requestFocus()
            return false
        }
        return true
    }

    private fun loadDatas() {
        Log.d( LOG_TAG, "loadDatas")

        this.checkBoxMonday.isChecked = mMySharePreferences!!.getBooleanPreference(MONDAY, true)
        this.checkBoxThuesday.isChecked = mMySharePreferences!!.getBooleanPreference(THUESDAY, true)
        this.checkBoxWednesday.isChecked = mMySharePreferences!!.getBooleanPreference(WEDNESDAY, true)
        this.checkBoxThursday.isChecked = mMySharePreferences!!.getBooleanPreference(THURSDAY, true)
        this.checkBoxFriday.isChecked = mMySharePreferences!!.getBooleanPreference(FRIDAY, true)
        this.checkBoxSaturday.isChecked = mMySharePreferences!!.getBooleanPreference(SATURDAY, true)
        this.checkBoxSunday.isChecked = mMySharePreferences!!.getBooleanPreference(SUNDAY, false)

        Log.d( LOG_TAG, "loadDatas TIME_START " + this.spinner_timestart.selectedItem.toString())

        this.spinner_timestart.setSelection(mMySharePreferences!!.getIntPreference(TIME_START_POS, DEFAULT_ITEM_SELECTED))
        this.spinner_timemiddle.setSelection(mMySharePreferences!!.getIntPreference(TIME_MIDDLE_POS, DEFAULT_ITEM_SELECTED))
        this.spinner_timemiddle2.setSelection(mMySharePreferences!!.getIntPreference(TIME_MIDDLE2_POS, DEFAULT_ITEM_SELECTED))
        this.spinner_timeend.setSelection(mMySharePreferences!!.getIntPreference(TIME_END_POS, DEFAULT_ITEM_SELECTED))

        Log.d( LOG_TAG, "loadDatas NOTIF_ACTION " + this.checkBoxActionNotif.isChecked)
        this.checkBoxActionNotif.isChecked = mMySharePreferences!!.getBooleanPreference(NOTIF_ACTION, false)
        this.checkBoxAlertNotif.isChecked = mMySharePreferences!!.getBooleanPreference(NOTIF_ISSUE, true)
        val smsphonenumbers = mMySharePreferences!!.getStringPreference(SMS_PHONENUMBERS)
        val alertemails = mMySharePreferences!!.getStringPreference(EMAILS_ADR)
        this.smsphonenumbers.setText(smsphonenumbers)
        this.alertemails.setText(alertemails)
        enableButtonTest()

        this.smsphonenumbers.isEnabled = this.checkBoxActionNotif.isChecked
        this.alertemails.isEnabled = this.checkBoxAlertNotif.isChecked

        if (!resources.getBoolean(R.bool.enable_sms)) {
            Log.d(LOG_TAG, "loadDatas -> enable_SMS false")
            this.checkBoxActionNotif.visibility = View.GONE
            this.smsphonenumbers.visibility = View.GONE
        }

        if (!resources.getBoolean(R.bool.enable_alert)) {
            Log.d(LOG_TAG, "loadDatas -> enable_alert false")
            this.checkBoxAlertNotif.visibility = View.GONE
            this.alertemails.visibility = View.GONE
        }

        if (!resources.getBoolean(R.bool.enable_sms) && !resources.getBoolean(R.bool.enable_alert)) {
            this.buttonTest.visibility = View.GONE
        }

        if (NetworkTools.isNetworkAvailable(this)){
            Log.d( LOG_TAG, "LoadDatas onReceive DATA_CONNECTED")
            this@MainAndSettingsActivity.checkBoxAlertNotif.visibility = View.VISIBLE
            this@MainAndSettingsActivity.alertemails.visibility = View.VISIBLE
            this@MainAndSettingsActivity.buttonTest.visibility = View.VISIBLE
        }
        else
        {
            Log.d( LOG_TAG, "LoadDatas NOT DATA_CONNECTED")
            this@MainAndSettingsActivity.checkBoxAlertNotif.visibility = View.GONE
            this@MainAndSettingsActivity.alertemails.visibility = View.GONE
            this@MainAndSettingsActivity.buttonTest.visibility = View.GONE
        }

        //startService()

    }

    override fun saveDatas() {
        Log.d( LOG_TAG, "saveDatas")

        mMySharePreferences!!.saveBooleanPreference(MONDAY, this.checkBoxMonday.isChecked)
        mMySharePreferences!!.saveBooleanPreference(THUESDAY, this.checkBoxThuesday.isChecked)
        mMySharePreferences!!.saveBooleanPreference(WEDNESDAY, this.checkBoxWednesday.isChecked)
        mMySharePreferences!!.saveBooleanPreference(THURSDAY, this.checkBoxThursday.isChecked)
        mMySharePreferences!!.saveBooleanPreference(FRIDAY, this.checkBoxFriday.isChecked)
        mMySharePreferences!!.saveBooleanPreference(SATURDAY, this.checkBoxSaturday.isChecked)
        mMySharePreferences!!.saveBooleanPreference(SUNDAY, this.checkBoxSunday.isChecked)

        Log.d( LOG_TAG, "saveDatas TIME_START " + this.spinner_timestart.selectedItem.toString())
        mMySharePreferences!!.saveStringPreference(TIME_START, this.spinner_timestart.selectedItem.toString())
        mMySharePreferences!!.saveStringPreference(TIME_MIDDLE, this.spinner_timemiddle.selectedItem.toString())
        mMySharePreferences!!.saveStringPreference(TIME_MIDDLE2, this.spinner_timemiddle2.selectedItem.toString())
        mMySharePreferences!!.saveStringPreference(TIME_END, this.spinner_timeend.selectedItem.toString())
        mMySharePreferences!!.saveIntPreference(TIME_START_POS, this.spinner_timestart.selectedItemPosition)
        mMySharePreferences!!.saveIntPreference(TIME_MIDDLE_POS, this.spinner_timemiddle.selectedItemPosition)
        mMySharePreferences!!.saveIntPreference(TIME_MIDDLE2_POS, this.spinner_timemiddle2.selectedItemPosition)
        mMySharePreferences!!.saveIntPreference(TIME_END_POS, this.spinner_timeend.selectedItemPosition)

        Log.d( LOG_TAG, "saveDatas NOTIF_ACTION " + this.checkBoxActionNotif.isChecked)
        mMySharePreferences!!.saveBooleanPreference(NOTIF_ACTION, this.checkBoxActionNotif.isChecked)
        mMySharePreferences!!.saveBooleanPreference(NOTIF_ISSUE, this.checkBoxAlertNotif.isChecked)
        Log.d( LOG_TAG, "saveDatas SMS_PHONENUMBERS " + this.smsphonenumbers.text.toString())
        mMySharePreferences!!.saveStringPreference(SMS_PHONENUMBERS, this.smsphonenumbers.text.toString())
        mMySharePreferences!!.saveStringPreference(EMAILS_ADR, this.alertemails.text.toString())

    }

}

