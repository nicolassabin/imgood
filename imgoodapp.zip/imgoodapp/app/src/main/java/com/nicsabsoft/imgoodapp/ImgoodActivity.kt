package com.nicsabsoft.imgoodapp


import android.os.Bundle
import android.util.Log
import android.view.animation.AnimationUtils
import android.os.Handler
import android.view.animation.Animation
import kotlinx.android.synthetic.main.activity_imgood.*
import kotlinx.android.synthetic.main.activity_operationvalidate.imageViewOperation
import kotlinx.android.synthetic.main.activity_operationvalidate.progressBar_cyclic


open class ImgoodActivity : AppBasedActivity() {

    companion object {

        private const val LOG_TAG = "ImgoodActivity"

    }

    /** The m mVolumeLevel.  */
    private var mShakeAnimation : Animation? = null

    /** The m handler.  */
    private val mHandler = Handler()

    /** The m mAnimationRunnable runnable.  */
    private val mAnimationRunnable = Runnable {
        Log.d(LOG_TAG, "mAnimationRunnable, ")
        this.imageViewOperation?.startAnimation(mShakeAnimation)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d( LOG_TAG, "onCreate")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_imgood)

        val actionBar = supportActionBar
        actionBar!!.setHomeButtonEnabled(true)
        actionBar.setDisplayHomeAsUpEnabled(true)

        mProgressBar = this.progressBar_cyclic

        mShakeAnimation = AnimationUtils.loadAnimation(this, R.anim.shake)

        this.buttonimgood_and_wakeup?.setOnClickListener {
            Log.d( LOG_TAG, "buttonimgood_and_wakeup setOnClickListener")
            sendNotification(getString(R.string.imgood_and_wakeup_smstext),
                    getString(R.string.imgood_and_wakeup_text))
            finish()
        }

        this.buttonimgood_and_launch?.setOnClickListener {
            Log.d( LOG_TAG, "buttonValidate buttonimgood_and_launch")
            sendNotification(getString(R.string.imgood_and_launch_smstext),
                    getString(R.string.imgood_and_launch_text))
            finish()
        }

        this.buttonimgood_and_reading?.setOnClickListener {
            Log.d( LOG_TAG, "buttonValidate buttonimgood_and_reading")
            sendNotification(getString(R.string.imgood_and_reading_smstext),
                    getString(R.string.imgood_and_reading_text))
            finish()
        }

        this.buttonimgood_and_watchtv?.setOnClickListener {
            Log.d( LOG_TAG, "buttonValidate buttonimgood_and_watchtv")
            sendNotification(getString(R.string.imgood_and_watchtv_smstext),
                    getString(R.string.imgood_and_watchtv_text))
            finish()
        }

        this.buttonimgood_and_thatall?.setOnClickListener {
            Log.d( LOG_TAG, "buttonValidate buttonimgood_and_thatall")
            sendNotification(getString(R.string.imgood_and_thatall_smstext),
                    getString(R.string.imgood_and_thatall_text))
            finish()
        }

        this.buttonClose?.setOnClickListener {
            Log.d( LOG_TAG, "buttonClose buttonimgood_and_thatall")
            sendNotification(getString(R.string.imgood_and_thatall_smstext),
                    getString(R.string.imgood_and_thatall_text))
            finish()
        }

    }

    override fun onResume() {
        Log.d( LOG_TAG, "onResume")
        // 1
        super.onResume()
        startAnimation()

    }
    override fun onBackPressed() {
        Log.d( LOG_TAG, "onBackPressed")
        sendNotification(getString(R.string.message_confirmation_imgood_smstext),
                getString(R.string.message_confirmation_imgood_text))

        super.onBackPressed()
    }

    override fun onPause() {
        Log.d( LOG_TAG, "onPause")
        stopAnimation()
        super.onPause()
    }

    override fun onDestroy() {
        Log.d( LOG_TAG, "onDestroy")
        mHandler.removeCallbacks(mAnimationRunnable)
        super.onDestroy()

    }

    private fun startAnimation() {
        Log.d( LOG_TAG, "startAnimation")
        mHandler.postDelayed(mAnimationRunnable, 200)
    }

    private fun stopAnimation() {
        Log.d( LOG_TAG, "stopAnimation")
        this.imageViewOperation?.clearAnimation()
    }

}

