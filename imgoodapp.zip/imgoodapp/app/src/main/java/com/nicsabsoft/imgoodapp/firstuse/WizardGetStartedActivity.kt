/*
 * Copyright 2019 nicsabsoft, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * nicsabsoft, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with nicsabsoft.
 */
package com.nicsabsoft.imgoodapp.firstuse

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.app.ActionBar
import android.support.v7.app.AppCompatActivity
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.UnderlineSpan
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView

import com.nicsabsoft.imgoodapp.R
import com.nicsabsoft.imgoodapp.utils.SpanTokensHelper


class WizardGetStartedActivity : AppCompatActivity() {

    /** The log tag.  */
    private val LOG_TAG = "WizardGetStartedActivity"

    /** The TextView terms and conditions.  */
    private var termsAndConditions: TextView? = null

    /** The m span tokens helper.  */
    private var mSpanTokensHelper: SpanTokensHelper? = null

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mSpanTokensHelper = SpanTokensHelper()
        overridePendingTransition(0, 0)

        setContentView(R.layout.splashscreen_connecting)

        val actionBar = supportActionBar
        actionBar?.hide()

        makeAllClickableAndVisible()

        this.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER
    }


    private fun startWizard() {
        val intent = Intent(this@WizardGetStartedActivity, WizardActivity::class.java)
        if (getIntent().extras != null) {
            intent.putExtras(getIntent().extras!!)
        }
        startActivity(intent)
        this.finish()
    }

    /**
     * Make terms and conditions clickable.
     */

    private fun makeTermsAndConditionsClickable() {
        var link: CharSequence = getString(R.string.get_started_terms_of_service)
        link = mSpanTokensHelper!!.setSpanBetweenTokens(link, "##", ForegroundColorSpan(ContextCompat.getColor(this,
                R.color.text_white)), UnderlineSpan(), object : ClickableSpan() {
            override fun onClick(widget: View) {
                launchTermsOfService(applicationContext)
            }
        })
        termsAndConditions!!.text = link
        termsAndConditions!!.gravity = Gravity.CENTER
        termsAndConditions!!.movementMethod = LinkMovementMethod.getInstance()
        termsAndConditions!!.visibility = View.VISIBLE
    }

    private fun makeAllClickableAndVisible() {
        val progressSplash = findViewById<View>(R.id.progressSplash) as ProgressBar
        val bottomLayout = findViewById<View>(R.id.splash_bottom) as RelativeLayout
        val getStartedButton = findViewById<View>(R.id.get_started_wizard_button) as Button
        getStartedButton.visibility = View.VISIBLE
        termsAndConditions = findViewById<View>(R.id.hook_terms_of_service_text) as TextView
        makeTermsAndConditionsClickable()

        progressSplash.visibility = View.GONE
        bottomLayout.visibility = View.VISIBLE

        getStartedButton.setOnClickListener { startWizard() }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setContentView(R.layout.splashscreen_connecting)
        makeAllClickableAndVisible()
    }

    /**
     * Launch terms of service.
     *
     * @param context the context
     */
    private fun launchTermsOfService(context: Context) {
        val intent = Intent(context, TermsOfService::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    companion object {

        /** The intent action wizard get started.  */
        val INTENT_ACTION_WIZARD_GET_STARTED = ".intent.action.WIZARD_GET_STARTED"
    }
}
