package com.nicsabsoft.imgoodapp.core.alarm

import android.annotation.SuppressLint
import android.content.Context
import android.media.MediaPlayer
import android.media.VolumeShaper
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import com.nicsabsoft.imgoodapp.R
import com.nicsabsoft.imgoodapp.core.utils.ResourceHelper





/**
 * The Class AlarmScenario.
 */
class AlarmScenario(private val mContext: Context, private val mView : View?,
                    private val mIAlarmScenario: IAlarmScenario) {

    companion object {

        private const val LOG_TAG = "AlarmScenario"

        private const val DEFAULT_VOLUME_VALUE = 20f

    }

    interface IAlarmScenario
    {
        fun notifyEndAlarmScenario()
    }

    /** The m mAlamSteps.  */
    private var mAlamSteps : MutableList<AlarmStep>? = ArrayList()

    /** The m mMediaPlayer.  */
    private var mMediaPlayer : MediaPlayer? = null

    /** The m mVolumeLevel.  */
    //private var mVolumeLevel = DEFAULT_VOLUME_VALUE

    /** The m mVolumeLevel.  */
    private var mShakeAnimation : Animation? = null

    /** The m handler.  */
    private val mHandler = Handler(Looper.getMainLooper())

    /** The m mMyCountDownTimer.  */
    private var mMyCountDownTimer : CountDownTimer? = null

    /** The m mCurrentIndex.  */
    private var mCurrentIndex: Int = 0

    /** The m mAnimationRunnable runnable.  */
    private val mAnimationRunnable = Runnable {
        Log.d(LOG_TAG, "mAnimationRunnable, ")
        mView?.startAnimation(mShakeAnimation)
    }

    /** The m mAnimationRunnable runnable.  */
    private val mStartMediaPlayerRunnable = Runnable {
        Log.d(LOG_TAG, "mStartMediaPlayerRunnable, ")
        stopAnimation()
        mMediaPlayer?.start()
    }

    private var mbInProgress : Boolean = false

    fun  getAlamSteps(): MutableList<AlarmStep>? {
        return mAlamSteps
    }
    @SuppressLint("ResourceType")
    fun init(nameArray: String){
        Log.d(LOG_TAG, "init")

        mShakeAnimation = AnimationUtils.loadAnimation(mContext, R.anim.shake)

        mAlamSteps?.clear()
        // load the scenario from the resources
        for (item in ResourceHelper.getMultiTypedArray(mContext, nameArray)) {
            val alarmstep = AlarmStep()
            alarmstep.index = item.getInt(0, 0)
            alarmstep.name = item.getString(1)
            alarmstep.soundResource = item.getString(2)
            alarmstep.animation = item.getBoolean(3, false)
            alarmstep.timeOut = item.getInt(4, 0).toLong()

            mAlamSteps?.add(alarmstep)
        }
    }

    fun getDuration(): Long{
        Log.d(LOG_TAG, "getDuration")

        var duration = 0L
        for (item in mAlamSteps!!) {
            duration += item.timeOut
        }

        Log.d(LOG_TAG, "getDuration duration $duration")
        return duration
    }

    /*fun isInProgress(): Boolean{

        Log.d(LOG_TAG, "isInProgress $mbInProgress")
        return mbInProgress
    }*/

    fun start() {
        Log.d(LOG_TAG, "start")
        start(0)
    }

    private fun start(index : Int){

        mCurrentIndex = index
        Log.d(LOG_TAG, "start mCurrentIndex $mCurrentIndex")

        stopCurrentAlarmStep()

        if (mCurrentIndex < mAlamSteps!!.size) {
            mbInProgress = true
            val alarmstepItem = mAlamSteps!![mCurrentIndex]
            Log.d(LOG_TAG, "start alarmstepItem index " + alarmstepItem.index
                    + " name " + alarmstepItem.name)
            if (alarmstepItem.animation) {
                Log.d(LOG_TAG, "start alarmstepItem Animation ")
                startAnimation()
            }

            if (alarmstepItem.soundResource.isNotEmpty()) {
                Log.d(LOG_TAG, "start alarmstepItem play sound " + alarmstepItem.soundResource)
                // Variable to hold service class name
                startSoundAlarm(alarmstepItem)
            }

            if (alarmstepItem.timeOut > 0) {
                Log.d(LOG_TAG, "start alarmstepItem TimeOut ${alarmstepItem.timeOut}")
                mMyCountDownTimer?.cancel()
                mMyCountDownTimer = object : CountDownTimer((alarmstepItem.timeOut * 1000),
                        2000L) {

                    override fun onTick(millisUntilFinished: Long) {
                        Log.d(LOG_TAG, "mMyCountDownTimer onTick ")

                    }

                    override fun onFinish() {
                        Log.d(LOG_TAG, "mMyCountDownTimer onFinish ")
                        start(mCurrentIndex+1)
                    }
                }.start()
            } else {
                Log.d(LOG_TAG, "start alarmstepItem No TimeOut ")
                start(mCurrentIndex+1)
            }
        } else {
            Log.d(LOG_TAG, "start end of scenario ")
            mIAlarmScenario.notifyEndAlarmScenario()
            mbInProgress = false
        }
    }

    fun stop(){
        Log.d(LOG_TAG, "stop")
        // stop the counttimer
        mbInProgress = false
        mMyCountDownTimer?.cancel()

        stopCurrentAlarmStep()

    }

    fun removeCallbacks(){
        Log.d(LOG_TAG, "removeCallbacks")
        mHandler.removeCallbacks(mAnimationRunnable)
        mHandler.removeCallbacks(mStartMediaPlayerRunnable)

    }

    private fun stopCurrentAlarmStep() {
        Log.d(LOG_TAG, "stopCurrentAlarmStep")
        stopAnimation()
        stopSoundAlarm()
    }

    private fun startSoundAlarm(alarmStep: AlarmStep?){
        Log.d( LOG_TAG, "startSoundAlarm soundResource " + alarmStep?.soundResource)

        mMediaPlayer?.release()
        mMediaPlayer = MediaPlayer.create(mContext, mContext.resources.getIdentifier(alarmStep?.soundResource, "raw",
                mContext.packageName))

        if (!mMediaPlayer!!.isPlaying)
        {
            //mMediaPlayer?.setVolume(mVolumeLevel,mVolumeLevel)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Log.d( LOG_TAG, "startSoundAlarm set progressive volume")
                val config: VolumeShaper.Configuration =
                VolumeShaper.Configuration.Builder()
                        .setDuration(alarmStep?.timeOut!!)
                        .setCurve(floatArrayOf(0f, 1f), floatArrayOf(0f, 1f))
                        .setInterpolatorType(VolumeShaper.Configuration.INTERPOLATOR_TYPE_LINEAR)
                        .build()
                val volumeShaper = mMediaPlayer?.createVolumeShaper(config)
                volumeShaper?.apply(VolumeShaper.Operation.PLAY)

            } else {
                Log.d( LOG_TAG, "startSoundAlarm no progressive volume")
                mMediaPlayer?.setVolume(alarmStep?.audioVolume!!, alarmStep.audioVolume)
            }
            mMediaPlayer?.isLooping = alarmStep?.audiolooping!!
            mMediaPlayer?.setScreenOnWhilePlaying(true)
            /*mMediaPlayer?.setOnCompletionListener {
                Log.d( LOG_TAG, "mMediaPlayer setOnCompletionListener")
                // increase the volume

                mVolumeLevel += DEFAULT_VOLUME_VALUE
                if (mVolumeLevel > 100f)
                {
                    mVolumeLevel = DEFAULT_VOLUME_VALUE
                }
                Log.d( LOG_TAG, "mMediaPlayer setVolume $mVolumeLevel")
                mMediaPlayer?.setVolume(mVolumeLevel,mVolumeLevel)
                startAnimation()
                mHandler.postDelayed(mStartMediaPlayerRunnable,2000)

            }*/
            mHandler.post(mStartMediaPlayerRunnable)
        }
        else
        {
            Log.d( LOG_TAG, "startSoundAlarm already playing")
        }
    }

    private fun stopSoundAlarm()
    {
        Log.d( LOG_TAG, "stopSoundAlarm")
        // Variable to hold service class name
        mMediaPlayer?.setScreenOnWhilePlaying(false)
        //mMediaPlayer?.setOnCompletionListener {  }
        mMediaPlayer?.stop()

    }

    private fun startAnimation() {
        Log.d( LOG_TAG, "startAnimation")
        mHandler.postDelayed(mAnimationRunnable, 500)
    }

    private fun stopAnimation() {
        Log.d( LOG_TAG, "stopAnimation")
        mView?.clearAnimation()
    }

    /**
     * The Class AlarmStep.
     */
    class AlarmStep {

        var index : Int = 0
        var name : String = ""
        var animation : Boolean = false
        var soundResource : String = ""
        var timeOut : Long = 0
        var audiolooping : Boolean = true
        var audioVolume : Float = DEFAULT_VOLUME_VALUE


    }

}