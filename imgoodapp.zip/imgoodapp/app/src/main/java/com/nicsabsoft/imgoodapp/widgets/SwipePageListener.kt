/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.nicsabsoft.imgoodapp.widgets

/**
 * The listener interface for receiving swipePage events. The class that is interested in processing a swipePage event
 * implements this interface, and the object created with that class is registered with a component using the
 * component's `addSwipePageListener` method. When
 * the swipePage event occurs, that object's appropriate
 * method is invoked.
`` */
interface SwipePageListener {

    /**
     * On page scrolled.
     * @param position the position
     * @param positionOffset the position offset
     * @param positionOffsetPixels the position offset pixels
     */
    fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int)

    /**
     * On page selected.
     * @param position the position
     */
    fun onPageSelected(position: Int)

    /**
     * On page scroll state changed.
     * @param state the state
     */
    fun onPageScrollStateChanged(state: Int)
}
