package com.nicsabsoft.imgoodapp.utils

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.util.Log
import android.widget.Toast

import com.nicsabsoft.imgoodapp.R

/**
 * Created by nsab0001 on 02/06/2017.
 */

class PermissionManager {


    /**
     * Permissions required to Network
     */
    private var _permissions = arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.INTERNET, Manifest.permission.ACCESS_NETWORK_STATE)


    /**
     * check all Permission.
     */
    fun checkAllPermission(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                Build.VERSION.SDK_INT <= Build.VERSION_CODES.O)
        {
            _permissions = arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.INTERNET, Manifest.permission.ACCESS_NETWORK_STATE,
                Manifest.permission.READ_PHONE_STATE)
            checkPermission(activity, Manifest.permission.READ_PHONE_STATE, _permissions)
        }
        checkPermission(activity, Manifest.permission.INTERNET, _permissions)
        checkPermission(activity, Manifest.permission.SEND_SMS, _permissions)
        checkPermission(activity, Manifest.permission.ACCESS_NETWORK_STATE, _permissions)
    }


    /**
     * check one Permission.
     */
    private fun checkPermission(activity: Activity, permission: String, permissions: Array<String>) {
        // Here, thisActivity is the current activity
        Log.d(TAG, "checkPermission $permission")
        if (ContextCompat.checkSelfPermission(activity,
                        permission) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity,
                            permission)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                Log.d(TAG, "checkPermission Show an explanation ")
                Toast.makeText(activity,
                        R.string.permissions_needed,
                        Toast.LENGTH_LONG).show()


            } else {

                // No explanation needed, we can request the permission.
                Log.d(TAG, "checkPermission No explanation needed, we can request the permission.")
                ActivityCompat.requestPermissions(activity,
                        permissions,
                        MY_ALL_PERMISSIONS_REQUEST)

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.


            }
        }
    }

    companion object {

        /** The MY_ALL_PERMISSIONS_REQUEST.  */
        const val MY_ALL_PERMISSIONS_REQUEST = 1

        private val TAG = "PermissionManager"
    }


}
