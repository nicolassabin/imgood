/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.nicsabsoft.imgoodapp.widgets

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Paint.ANTI_ALIAS_FLAG
import android.os.Parcel
import android.os.Parcelable
import android.support.v4.content.ContextCompat
import android.support.v4.view.MotionEventCompat
import android.support.v4.view.ViewConfigurationCompat
import android.support.v4.view.ViewPager
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.LinearLayout.HORIZONTAL
import android.widget.LinearLayout.VERTICAL
import com.nicsabsoft.imgoodapp.R

/**
 * The Class CirclePageIndicator.
 */
class CirclePageIndicator
/**
 * Instantiates a new circle page indicator.
 * @param context the context
 * @param attrs the attrs
 * @param defStyle the def style
 */
@JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyle: Int = R.attr.vpiCirclePageIndicatorStyle) : View(context, attrs, defStyle), CirclePager {

    /** The m radius.  */
    private var mRadius: Float = 0.toFloat()

    /** The m paint page fill.  */
    private val mPaintPageFill = Paint(ANTI_ALIAS_FLAG)

    /** The m paint stroke.  */
    private val mPaintStroke = Paint(ANTI_ALIAS_FLAG)

    /** The m paint fill.  */
    private val mPaintFill = Paint(ANTI_ALIAS_FLAG)

    /** The m view pager.  */
    private var mViewPager: ViewPager? = null

    /** The m listener.  */
    private var mListener: ViewPager.OnPageChangeListener? = null

    /** The m current page.  */
    private var mCurrentPage: Int = 0

    /** The m snap page.  */
    private var mSnapPage: Int = 0

    /** The m page offset.  */
    private var mPageOffset: Float = 0.toFloat()

    /** The m scroll state.  */
    private var mScrollState: Int = 0

    /** The m orientation.  */
    private var mOrientation: Int = 0

    /** The m centered.  */
    private var mCentered: Boolean = false

    /** The m snap.  */
    private var mSnap: Boolean = false

    /** The m touch slop.  */
    private var mTouchSlop: Int = 0

    /** The m last motion x.  */
    private var mLastMotionX = -1f

    /** The m active pointer id.  */
    private var mActivePointerId = INVALID_POINTER

    /** The m is dragging.  */
    private var mIsDragging: Boolean = false

    /**
     * Gets the orientation.
     * @return the orientation
     */
    /**
     * Sets the orientation.
     * @param orientation the new orientation
     */
    var orientation: Int
        get() = mOrientation
        set(orientation) = when (orientation) {
            HORIZONTAL, VERTICAL -> {
                mOrientation = orientation
                requestLayout()
            }

            else -> throw IllegalArgumentException("Orientation must be either HORIZONTAL or VERTICAL.")
        }

    /**
     * Gets the stroke color.
     * @return the stroke color
     */
    /**
     * Sets the stroke color.
     * @param strokeColor the new stroke color
     */
    var strokeColor: Int
        get() = mPaintStroke.color
        set(strokeColor) {
            mPaintStroke.color = strokeColor
            invalidate()
        }

    init {
        if (!isInEditMode){

            // Load defaults from resources
            val res = resources
            val defaultPageColor = ContextCompat.getColor(context, R.color.uiwidgets_default_circle_indicator_page_color)
            val defaultFillColor = ContextCompat.getColor(context,R.color.uiwidgets_default_circle_indicator_fill_color)
            val defaultOrientation = res.getInteger(R.integer.uiwidgets_default_circle_indicator_orientation)
            val defaultStrokeColor = ContextCompat.getColor(context,R.color.uiwidgets_default_circle_indicator_stroke_color)
            val defaultStrokeWidth = res.getDimension(R.dimen.uiwidgets_default_circle_indicator_stroke_width)
            val defaultRadius = res.getDimension(R.dimen.uiwidgets_default_circle_indicator_radius)
            val defaultCentered = res.getBoolean(R.bool.uiwidgets_default_circle_indicator_centered)
            val defaultSnap = res.getBoolean(R.bool.uiwidgets_default_circle_indicator_snap)

            // Retrieve styles attributes
            val a = context.obtainStyledAttributes(attrs, R.styleable.UIWidgetsCirclePageIndicator, defStyle, 0)

            mCentered = a.getBoolean(R.styleable.UIWidgetsCirclePageIndicator_centered, defaultCentered)
            mOrientation = a.getInt(R.styleable.UIWidgetsCirclePageIndicator_android_orientation, defaultOrientation)
            mPaintPageFill.style = Paint.Style.FILL
            mPaintPageFill.color = a.getColor(R.styleable.UIWidgetsCirclePageIndicator_pageColor, defaultPageColor)
            mPaintStroke.style = Paint.Style.STROKE
            mPaintStroke.color = a.getColor(R.styleable.UIWidgetsCirclePageIndicator_strokeColor, defaultStrokeColor)
            mPaintStroke.strokeWidth = a.getDimension(R.styleable.UIWidgetsCirclePageIndicator_strokeWidth,
                    defaultStrokeWidth)
            mPaintFill.style = Paint.Style.FILL
            mPaintFill.color = a.getColor(R.styleable.UIWidgetsCirclePageIndicator_fillColor, defaultFillColor)
            mRadius = a.getDimension(R.styleable.UIWidgetsCirclePageIndicator_radius, defaultRadius)
            mSnap = a.getBoolean(R.styleable.UIWidgetsCirclePageIndicator_snap, defaultSnap)

            val background = a.getDrawable(R.styleable.UIWidgetsCirclePageIndicator_android_background)
            if (background != null) {
                setBackgroundDrawable(background)
            }

            a.recycle()

            val configuration = ViewConfiguration.get(context)
            mTouchSlop = ViewConfigurationCompat.getScaledPagingTouchSlop(configuration)
        }
    }


    /**
     * @see android.view.View.onDraw
     */
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (mViewPager == null) {
            return
        }
        val count = mViewPager!!.adapter.count
        if (count == 0) {
            return
        }

        if (mCurrentPage >= count) {
            setCurrentItem(count - 1)
            return
        }

        val longSize: Int
        val longPaddingBefore: Int
        val longPaddingAfter: Int
        val shortPaddingBefore: Int
        if (mOrientation == HORIZONTAL) {
            longSize = width
            longPaddingBefore = paddingLeft
            longPaddingAfter = paddingRight
            shortPaddingBefore = paddingTop
        } else {
            longSize = height
            longPaddingBefore = paddingTop
            longPaddingAfter = paddingBottom
            shortPaddingBefore = paddingLeft
        }

        val threeRadius = mRadius * 3
        val shortOffset = shortPaddingBefore + mRadius
        var longOffset = longPaddingBefore + mRadius
        if (mCentered) {
            longOffset += (longSize - longPaddingBefore - longPaddingAfter) / 2.0f - count * threeRadius / 2.0f
        }

        var dX: Float
        var dY: Float

        var pageFillRadius = mRadius
        if (mPaintStroke.strokeWidth > 0) {
            pageFillRadius -= mPaintStroke.strokeWidth / 2.0f
        }

        // Draw stroked circles
        for (iLoop in 0 until count) {
            val drawLong = longOffset + iLoop * threeRadius
            if (mOrientation == HORIZONTAL) {
                dX = drawLong
                dY = shortOffset
            } else {
                dX = shortOffset
                dY = drawLong
            }
            // Only paint fill if not completely transparent
            if (mPaintPageFill.alpha > 0) {
                canvas.drawCircle(dX, dY, pageFillRadius, mPaintPageFill)
            }

            // Only paint stroke if a stroke width was non-zero
            if (pageFillRadius != mRadius) {
                canvas.drawCircle(dX, dY, mRadius, mPaintStroke)
            }
        }

        // Draw the filled circle according to the current scroll
        var cx = (if (mSnap) mSnapPage else mCurrentPage) * threeRadius
        if (!mSnap) {
            cx += mPageOffset * threeRadius
        }
        if (mOrientation == HORIZONTAL) {
            dX = longOffset + cx
            dY = shortOffset
        } else {
            dX = shortOffset
            dY = longOffset + cx
        }
        canvas.drawCircle(dX, dY, mRadius, mPaintFill)
    }

    /**
     * @see android.view.View.onTouchEvent
     */
    override fun onTouchEvent(ev: android.view.MotionEvent): Boolean {
        if (super.onTouchEvent(ev)) {
            return true
        }
        if (mViewPager == null || mViewPager!!.adapter.count == 0) {
            return false
        }

        val action = ev.action and MotionEventCompat.ACTION_MASK
        when (action) {
            MotionEvent.ACTION_DOWN -> {
                mActivePointerId = MotionEventCompat.getPointerId(ev, 0)
                mLastMotionX = ev.x
            }

            MotionEvent.ACTION_MOVE -> {
                val activePointerIndex = MotionEventCompat.findPointerIndex(ev, mActivePointerId)
                val x = MotionEventCompat.getX(ev, activePointerIndex)
                val deltaX = x - mLastMotionX

                if (!mIsDragging) {
                    if (Math.abs(deltaX) > mTouchSlop) {
                        mIsDragging = true
                    }
                }

                if (mIsDragging) {
                    mLastMotionX = x
                    if (mViewPager!!.isFakeDragging || mViewPager!!.beginFakeDrag()) {
                        mViewPager!!.fakeDragBy(deltaX)
                    }
                }
            }

            MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_UP -> {
                if (!mIsDragging) {
                    val count = mViewPager!!.adapter.count
                    val width = width
                    val halfWidth = width / 2f
                    val sixthWidth = width / 6f

                    if (mCurrentPage > 0 && ev.x < halfWidth - sixthWidth) {
                        if (action != MotionEvent.ACTION_CANCEL) {
                            mViewPager!!.currentItem = mCurrentPage - 1
                        }
                        return true
                    } else if (mCurrentPage < count - 1 && ev.x > halfWidth + sixthWidth) {
                        if (action != MotionEvent.ACTION_CANCEL) {
                            mViewPager!!.currentItem = mCurrentPage + 1
                        }
                        return true
                    }
                }

                mIsDragging = false
                mActivePointerId = INVALID_POINTER
                if (mViewPager!!.isFakeDragging)
                    mViewPager!!.endFakeDrag()
            }

            MotionEventCompat.ACTION_POINTER_DOWN -> {
                val index = MotionEventCompat.getActionIndex(ev)
                mLastMotionX = MotionEventCompat.getX(ev, index)
                mActivePointerId = MotionEventCompat.getPointerId(ev, index)
            }

            MotionEventCompat.ACTION_POINTER_UP -> {
                val pointerIndex = MotionEventCompat.getActionIndex(ev)
                val pointerId = MotionEventCompat.getPointerId(ev, pointerIndex)
                if (pointerId == mActivePointerId) {
                    val newPointerIndex = if (pointerIndex == 0) 1 else 0
                    mActivePointerId = MotionEventCompat.getPointerId(ev, newPointerIndex)
                }
                mLastMotionX = MotionEventCompat.getX(ev, MotionEventCompat.findPointerIndex(ev, mActivePointerId))
            }
        }

        return true
    }

    /**
     *
     */
    override fun setViewPager(view: ViewPager) {
        if (mViewPager === view) {
            return
        }
        if (mViewPager != null) {
            mViewPager!!.setOnPageChangeListener(null)
        }
        if (view.adapter == null) {
            throw IllegalStateException("ViewPager does not have adapter getInstance.")
        }
        mViewPager = view
        mViewPager!!.setOnPageChangeListener(this)
        invalidate()
    }

    /**
     *
     */
    override fun setViewPager(view: ViewPager, initialPosition: Int) {
        setViewPager(view)
        setCurrentItem(initialPosition)
    }

    /**
     *
     */
    override fun setCurrentItem(item: Int) {
        if (mViewPager == null) {
            throw IllegalStateException("ViewPager has not been bound.")
        }
        mViewPager!!.currentItem = item
        mCurrentPage = item
        invalidate()
    }

    /**
     *
     */
    override fun notifyDataSetChanged() {
        invalidate()
    }

    /**
     *
     */
    override fun onPageScrollStateChanged(state: Int) {
        mScrollState = state

        if (mListener != null) {
            mListener!!.onPageScrollStateChanged(state)
        }
    }

    /**
     * @see android.support.v4.view.ViewPager.OnPageChangeListener.onPageScrolled
     */
    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
        mCurrentPage = position
        mPageOffset = positionOffset
        invalidate()

        if (mListener != null) {
            mListener!!.onPageScrolled(position, positionOffset, positionOffsetPixels)
        }
    }

    /**
     * @see android.support.v4.view.ViewPager.OnPageChangeListener.onPageSelected
     */
    override fun onPageSelected(position: Int) {
        if (mSnap || mScrollState == ViewPager.SCROLL_STATE_IDLE) {
            mCurrentPage = position
            mSnapPage = position
            invalidate()
        }

        if (mListener != null) {
            mListener!!.onPageSelected(position)
        }
    }

    /**
     *
     */
    override fun setOnPageChangeListener(listener: ViewPager.OnPageChangeListener) {
        mListener = listener
    }

    /*
     * (non-Javadoc)
     * @see android.view.View#onMeasure(int, int)
     */
    /**
     * @see android.view.View.onMeasure
     */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (mOrientation == HORIZONTAL) {
            setMeasuredDimension(measureLong(widthMeasureSpec), measureShort(heightMeasureSpec))
        } else {
            setMeasuredDimension(measureShort(widthMeasureSpec), measureLong(heightMeasureSpec))
        }
    }

    /**
     * Determines the width of this view.
     * @param measureSpec A measureSpec packed into an int
     * @return The width of the view, honoring constraints from measureSpec
     */
    private fun measureLong(measureSpec: Int): Int {
        var result: Int
        val specMode = MeasureSpec.getMode(measureSpec)
        val specSize = MeasureSpec.getSize(measureSpec)

        if (specMode == MeasureSpec.EXACTLY || mViewPager == null) {
            // We were told how big to be
            result = specSize
        } else {
            // Calculate the width according the views count
            val count = mViewPager!!.adapter.count
            result = (paddingLeft.toFloat() + paddingRight.toFloat() + count.toFloat() * 2f * mRadius + (count - 1) * mRadius + 1f).toInt()
            // Respect AT_MOST value if that was what is called for by measureSpec
            if (specMode == View.MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize)
            }
        }
        return result
    }

    /**
     * Determines the height of this view.
     * @param measureSpec A measureSpec packed into an int
     * @return The height of the view, honoring constraints from measureSpec
     */
    private fun measureShort(measureSpec: Int): Int {
        var result: Int
        val specMode = View.MeasureSpec.getMode(measureSpec)
        val specSize = View.MeasureSpec.getSize(measureSpec)

        if (specMode == View.MeasureSpec.EXACTLY) {
            // We were told how big to be
            result = specSize
        } else {
            // Measure the height
            result = (2 * mRadius + paddingTop.toFloat() + paddingBottom.toFloat() + 1f).toInt()
            // Respect AT_MOST value if that was what is called for by measureSpec
            if (specMode == View.MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize)
            }
        }
        return result
    }

    /**
     * @see android.view.View.onRestoreInstanceState
     */
    public override fun onRestoreInstanceState(state: Parcelable) {
        val savedState = state as SavedState
        super.onRestoreInstanceState(savedState.superState)
        mCurrentPage = savedState.currentPage
        mSnapPage = savedState.currentPage
        requestLayout()
    }

    /**
     * @see android.view.View.onSaveInstanceState
     */
    public override fun onSaveInstanceState(): Parcelable? {
        val superState = super.onSaveInstanceState()
        val savedState = SavedState(superState)
        savedState.currentPage = mCurrentPage
        return savedState
    }

    /**
     * The Class SavedState.
     */
    internal class SavedState : View.BaseSavedState {

        /** The current page.  */
        var currentPage: Int = 0

        /**
         * Instantiates a new saved state.
         * @param superState the super state
         */
        constructor(superState: Parcelable) : super(superState) {}

        /**
         * Instantiates a new saved state.
         * @param in the in
         */
        private constructor(`in`: Parcel) : super(`in`) {
            currentPage = `in`.readInt()
        }

        /**
         * @see android.view.AbsSavedState.writeToParcel
         */
        override fun writeToParcel(dest: Parcel, flags: Int) {
            super.writeToParcel(dest, flags)
            dest.writeInt(currentPage)
        }

        companion object {

            /** The Constant CREATOR.  */
            @SuppressLint("ParcelCreator")
            val CREATOR: Parcelable.Creator<SavedState> = object : Parcelable.Creator<SavedState> {
                override fun createFromParcel(`in`: Parcel): SavedState {
                    return SavedState(`in`)
                }

                override fun newArray(size: Int): Array<SavedState?> {
                    return arrayOfNulls(size)
                }
            }
        }
    }

    companion object {

        /** The Constant INVALID_POINTER.  */
        private val INVALID_POINTER = -1
    }
}

