/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.nicsabsoft.imgoodapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.KeyEvent
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.TextView

import com.nicsabsoft.imgoodapp.R

/**
 * The Class WarningActivity.
 */
class WarningActivity : AppCompatActivity(), OnClickListener {

    /** The m back to main.  */
    protected var mBackToMain = false

    /** The m do exit.  */
    protected var mDoExit = false

    /** The m do intent activity manager exit.  */
    protected var mDoIntentActivityManagerExit = false

    /** The m is for result.  */
    protected var mIsForResult = false

    /**
     * Checks if is for result.
     * @return true, if is for result
     */
    protected val isForResult: Boolean
        get() = false

    /**
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.alert_dialog)
        mBackToMain = false
        mDoExit = false
        initFields()
    }

    /**
     * Inits the fields.
     */
    private fun initFields() {
        setTitle(TITLE, TITLE_FULL)
        this.setText(R.id.dialog_message, HEAD, HEAD_FULL)
        this.setText(R.id.dialog_message1, BODY, BODY_FULL)

        val extras = intent.extras
        if (extras != null) {
            mBackToMain = extras.getBoolean(BACK_TO_MAIN)
            mDoExit = extras.getBoolean(DO_EXIT)
            mDoIntentActivityManagerExit = extras.getBoolean(DO_INTENT_ACTIVITY_MANAGER_EXIT)
        } else {
            mBackToMain = false
            mDoExit = false
            mDoIntentActivityManagerExit = false
        }
        mIsForResult = isForResult
        if (mIsForResult) {
            setResult(Activity.RESULT_CANCELED)
        }

        val buttonLeft = findViewById<View>(R.id.dialog_button_left) as Button
        val buttonRight = findViewById<View>(R.id.dialog_button_right) as Button
        var buttonString = getString(R.string.ok)
        val stringMessageId = extras?.getInt(BUTTON_TEXT_1) ?: 0
        if (stringMessageId != 0) {
            buttonString = getString(stringMessageId)
        }
        buttonRight.text = buttonString
        if (extras != null && extras.getBoolean(getString(R.string.cancel))) {
            buttonLeft.text = getString(R.string.cancel)
        }
    }

    /**
     * On new intent.
     * @param intent the intent
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        initFields()
    }

    /**
     * Sets the text.
     * @param destinationId the destination id
     * @param name the name
     * @param fullName the full name
     */
    private fun setText(destinationId: Int, name: String, fullName: String) {
        val view = findViewById<View>(destinationId) as TextView
        val extras = intent.extras
        val stringMessageId = extras?.getInt(name) ?: 0
        val stringMessage = extras?.getString(fullName)
        // if id specified
        if (stringMessageId != 0) {
            view.setText(stringMessageId)
            view.visibility = View.VISIBLE
        } else if (stringMessage != null) {
            // if id not specified but string specified
            view.text = stringMessage
            view.visibility = View.VISIBLE
        } else {
            view.visibility = View.GONE
        }
    }

    /**
     * Sets the title.
     * @param name the name
     * @param fullName the full name
     */
    private fun setTitle(name: String, fullName: String) {
        val extras = intent.extras
        val dialogTitle = findViewById<View>(R.id.title) as TextView
        val stringMessageId = extras?.getInt(name) ?: 0
        val stringMessage = extras?.getString(fullName)
        // if id specified
        if (stringMessageId != 0) {
            dialogTitle.setText(stringMessageId)
            // For Accessibility TalkBack service, for more info see SDCANDTACT-6773
            setTitle(stringMessageId)
        } else if (stringMessage != null) {
            // if id not specified but string specified
            dialogTitle.text = stringMessage
            // For Accessibility TalkBack service, for more info see SDCANDTACT-6773
            title = stringMessage
        }
    }

    /**
     * Exit on intent activity manager launch.
     */
    private fun exitOnIntentActivityManagerLaunch() {
        finish()
    }

    /**
     * Do close.
     * @param returnFlag the return flag
     * @return true, if successful
     */
    protected fun doClose(returnFlag: Boolean): Boolean {
        var retFlag = returnFlag
        if (mDoIntentActivityManagerExit) {
            exitOnIntentActivityManagerLaunch()
            return false
        }

        if (mBackToMain) {
            finish()
            val i = Intent(this, (application as TheApplication).getMainActivity())
            i.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(i)
            retFlag = true
        }
        return retFlag
    }

    /**
     *
     */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        var res = super.onKeyDown(keyCode, event)
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            res = doClose(res)
        }
        return res
    }

    /**
     * On click.
     * @param view the view
     */
    override fun onClick(view: View) {
        if (mIsForResult) {
            setResult(Activity.RESULT_OK)
        }

        if (!doClose(false)) {
            finish()
        }
    }

    /**
     *
     */
    override fun onPause() {
        super.onPause()
        if (mDoIntentActivityManagerExit) {
            exitOnIntentActivityManagerLaunch()
        }
    }

    companion object {

        /** The Constant TITLE.  */
        val TITLE = "TITLE"

        /** The Constant HEAD.  */
        val HEAD = "HEAD"

        /** The Constant BODY.  */
        val BODY = "BODY"

        /** The Constant BUTTON_TEXT_1.  */
        val BUTTON_TEXT_1 = "BUTTON"

        /** The Constant TITLE_FULL.  */
        val TITLE_FULL = "TITLE_FULL"

        /** The Constant HEAD_FULL.  */
        val HEAD_FULL = "HEAD_FULL"

        /** The Constant BODY_FULL.  */
        val BODY_FULL = "BODY_FULL"

        /** The Constant BACK_TO_MAIN.  */
        val BACK_TO_MAIN = "BACK_TO_MAIN"

        /** The Constant DO_EXIT.  */
        val DO_EXIT = "DO_EXIT"

        /** The Constant DO_INTENT_ACTIVITY_MANAGER_EXIT.  */
        val DO_INTENT_ACTIVITY_MANAGER_EXIT = "do_intent_activity_manager_exit"
    }

}
