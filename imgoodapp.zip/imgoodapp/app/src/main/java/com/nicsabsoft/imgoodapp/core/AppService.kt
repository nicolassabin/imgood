package com.nicsabsoft.imgoodapp.core

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.support.annotation.RequiresApi
import android.telephony.TelephonyManager
import android.util.Log
import android.widget.Toast
import com.nicsabsoft.imgoodapp.*
import com.nicsabsoft.imgoodapp.utils.MySharePreferences
import java.util.*
import com.nicsabsoft.imgoodapp.Constants.Companion.DEFAULT_ITEM_SELECTED
import com.nicsabsoft.imgoodapp.Constants.Companion.FRIDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.MONDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.SATURDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.SUNDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.THUESDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.THURSDAY
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_END_POS
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_MIDDLE2_POS
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_MIDDLE_POS
import com.nicsabsoft.imgoodapp.Constants.Companion.TIME_START_POS
import com.nicsabsoft.imgoodapp.Constants.Companion.WEDNESDAY
import com.nicsabsoft.imgoodapp.core.http.HttpRequestHelper
import com.nicsabsoft.imgoodapp.utils.MySMSManager
import java.text.SimpleDateFormat



class AppService : Service() {

    companion object {

        /** The INTENT_ACTION_APP_SERVICE_STARTED  */
        const val INTENT_ACTION_APP_SERVICE_STARTED = "INTENT_ACTION_APP_SERVICE_STARTED";
        /** The PARAM_ACTION  */
        const val PARAM_ACTION = "PARAM_ACTION"
        /** The ACTION_SEND_ALERT  */
        const val ACTION_SEND_ALERT = "ACTION_SEND_ALERT"

        /** The ACTION_NOTIF_ACTION  */
        const val ACTION_NOTIF_ACTION = "ACTION_NOTIF_ACTION"

        /** The NOTIF_MESSAGE_TEXT  */
        const val NOTIF_MESSAGE_TEXT = "NOTIF_MESSAGE_TEXT"

        /** The NOTIF_SMS_TEXT  */
        const val NOTIF_SMS_TEXT = "NOTIF_SMS_TEXT"


        /** The ACTION_SET_ALARM  */
        const val ACTION_SET_ALARM = "ACTION_SET_ALARM"

        /** The EXTRA_ALARM  */
        const val EXTRA_ALARM = "EXTRA_ALARM";

        /** The EXTRA_SETALARM_NEXTDAY  */
        const val EXTRA_SETALARM_NEXTDAY = "EXTRA_SETALARM_NEXTDAY";

        private const val LOG_TAG = "AppService";
        private const val LOCAL_ALARM = "AppServiceLOCAL_ALARM123456789";
        private const val LOCAL_ALARM_REQUEST_CODE = 1;


    }

    /** The m MySharePreferences.  */
    private var mMySharePreferences: MySharePreferences? = null

    /** The m mAlarmManager.  */
    private var mAlarmManager : AlarmManager? = null

    /** The m mTelephonyManager.  */
    private var mTelephonyManager: TelephonyManager? = null

    /** The m mReceiverAlarm.  */
    private var mReceiverAlarm: BroadcastReceiver? = null

    /** The m mReceiverSms.  */
    private var mReceiverSms: BroadcastReceiver? = null

    /** The m mTelephonyManager.  */
    private var mPendingIntent: PendingIntent? = null

    /** The m HttpRequestHelper.  */
    protected var mHttpRequestHelper: HttpRequestHelper? = null

    /** The m MySMSManager.  */
    private var mMySMSManager: MySMSManager? = null

    /** The m handler.  */
    private val mHandler = Handler()

    override fun onCreate() {
        Log.d(LOG_TAG, "onCreate")
        super.onCreate()

        mMySharePreferences = (application as TheApplication).mySharePreferences

        mTelephonyManager = this.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

        mMySMSManager = MySMSManager(this)

        mHttpRequestHelper = HttpRequestHelper(this, getString(R.string.serverurl))

        mAlarmManager = this.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent()
        intent.action = LOCAL_ALARM
        mPendingIntent = PendingIntent.getBroadcast(this, LOCAL_ALARM_REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT)

        mReceiverAlarm = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                Log.d(LOG_TAG, "mReceiverAlarm onReceive")
                if (intent.action == LOCAL_ALARM) {
                    Log.d(LOG_TAG, "mReceiverAlarm onReceive LOCAL_ALARM tired")
                    val i = Intent(context, OperationValidateActivity::class.java)
                    i.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    context.startActivity(i)
                }
            }
        }

        registerReceiver(mReceiverAlarm, IntentFilter(LOCAL_ALARM))

        if (resources.getBoolean(R.bool.notification_useservice)){
            mReceiverSms = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    Log.d(LOG_TAG, "SMS correctly sent")
                    displayInfo(context.getString(R.string.sms_sent))
                }
            }
            registerReceiver(mReceiverSms, IntentFilter(MySMSManager.SMS_SENT))
        }


    }


    override fun onBind(intent: Intent): IBinder? {
        Log.d(LOG_TAG, "onBind")
        throw UnsupportedOperationException("Not yet implemented")
    }



    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        // Send a notification that service is started
        Log.d(LOG_TAG, "onStartCommand")
        val intentResult = Intent(INTENT_ACTION_APP_SERVICE_STARTED)
        intentResult.setPackage(applicationContext.packageName)

        val action = intent.getStringExtra(PARAM_ACTION)
        Log.d(LOG_TAG, "onStartCommand action $action")
        if (ACTION_SEND_ALERT.equals(action, ignoreCase = true)) {
            Log.d(LOG_TAG, "onStartCommand ACTION_SEND_ALERT")
            val thread = Thread(Runnable {
                sendAlertMessage()
            })
            thread.start()
        } else if (ACTION_NOTIF_ACTION.equals(action, ignoreCase = true)) {
            Log.d(LOG_TAG, "onStartCommand ACTION_NOTIF_ACTION")
            val threadSms = Thread(Runnable {
                sendActionNotif(intent.getStringExtra(NOTIF_SMS_TEXT), intent.getStringExtra(NOTIF_MESSAGE_TEXT))
            })
            threadSms.start()
        }
        else if (ACTION_SET_ALARM.equals(action, ignoreCase = true)) {
            Log.d(LOG_TAG, "onStartCommand ACTION_SET_ALARM")
            intentResult.putExtra(EXTRA_ALARM, setAlarm(intent.getBooleanExtra(EXTRA_SETALARM_NEXTDAY, false)))
        }

        sendBroadcast(intentResult)
        return Service.START_STICKY
    }

    override fun onDestroy() {
        Log.d(LOG_TAG, "onDestroy")
        mAlarmManager?.cancel(mPendingIntent)
        unregisterReceiver(mReceiverAlarm)
        if (resources.getBoolean(R.bool.notification_useservice)) {
            unregisterReceiver(mReceiverSms)
        }
        super.onDestroy()
    }


    private fun setAlarm(nextDay: Boolean):Long
    {
        Log.d(LOG_TAG, "setAlarm nextDay " + nextDay)

        // check if notification is correctly configured
        if (mMySharePreferences!!.notificationValid()) {
            var calendar = Calendar.getInstance()
            calendar.timeInMillis = System.currentTimeMillis()

            Log.d(LOG_TAG, "setAlarm configure for next day")
            if (resources.getBoolean(R.bool.alarm_test)) {
                Log.d(LOG_TAG, "setAlarm -> alarm_test configure for next day, replace by 2 minutes")
                calendar.timeInMillis += 120000
            } else {
                // set the time calendar
                setTimeCalendar(nextDay, calendar)
            }
            setAlarmManager(calendar.timeInMillis)
            return calendar.timeInMillis
        }
        else
        {
            Log.d(LOG_TAG, "setAlarm configure not set due to bad notification config")
            return -1L;
        }

    }

    private fun setAlarmManager(time: Long)
    {
        Log.d(LOG_TAG, "setAlarmManager")

        // cancel all the previous alarm
        mAlarmManager?.cancel(mPendingIntent)

        // only one must be set at this time

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val ac = AlarmManager.AlarmClockInfo(time,
                    mPendingIntent)
            mAlarmManager?.setAlarmClock(ac, mPendingIntent)
        }
        else
        {

            mAlarmManager?.set(AlarmManager.RTC_WAKEUP, time, mPendingIntent)
        }
    }

    private fun setTimeCalendar(nextDay: Boolean, calendar: Calendar):Long
    {
        val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm:ss")
        Log.d(LOG_TAG, "Al setTimeCalendar nextDay " + nextDay + " currenttime " + dateFormat.format(Date(calendar.timeInMillis )))
        // set the day
        Log.d(LOG_TAG, "Al setTimeCalendar DAY_OF_YEAR" + calendar.get(Calendar.DAY_OF_YEAR))
        if (nextDay){
            calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) + getNextDayIndex(calendar.get(Calendar.DAY_OF_WEEK)))
        }
        Log.d(LOG_TAG, "Al setTimeCalendar DAY_OF_YEAR" + calendar.get(Calendar.DAY_OF_YEAR))

        // set the hour
        return setHourMinutes(calendar)
    }

    private fun getNextDayIndex(currentDayOfWeek: Int):Int{

        Log.d(LOG_TAG, "Al getNextDayIndex currentDayOfWeek " + currentDayOfWeek)
        var i = currentDayOfWeek + 1
        var u = 1
        while (u <= 7)
        {
            if (mMySharePreferences!!.getBooleanPreference(getDayIndex(i), false))
            {
                if (i > currentDayOfWeek)
                {
                    i = i-currentDayOfWeek;
                }
                else
                {
                    i = 7-currentDayOfWeek + i
                }
                Log.d(LOG_TAG, "Al getNextDayIndex return value " + i)
                return i
            }
            i++
            if (i > 7)
            {
                i = 1
            }
            u++
        }

        return 1;
    }

    private fun getDayIndex(indexDay: Int):String{

        Log.d(LOG_TAG, "Al getDayIndex indexDay " + indexDay)
        var sDay = SUNDAY
        when(indexDay)
        {
            1 -> sDay = SUNDAY
            2 -> sDay = MONDAY
            3 -> sDay = THUESDAY
            4 -> sDay = WEDNESDAY
            5 -> sDay = THURSDAY
            6 -> sDay = FRIDAY
            7 -> sDay = SATURDAY
        }
        Log.d(LOG_TAG, "Al getDayIndex return " + sDay)

        return sDay
    }

    private fun setHourMinutes(calendar: Calendar):Long{

        Log.d(LOG_TAG, "Al setHourMinutes ")

        val settingstimestart = getResources ().getStringArray(R.array.settings_timestart)
        val settingstimemiddle = getResources ().getStringArray(R.array.settings_timemiddle)
        val settingstimemiddle2 = getResources ().getStringArray(R.array.settings_timemiddle2)
        val settingstimeend = getResources ().getStringArray(R.array.settings_timeend)

        // add the time selected
        val iselstart = mMySharePreferences!!.getIntPreference(TIME_START_POS, DEFAULT_ITEM_SELECTED)
        val iselmiddle= mMySharePreferences!!.getIntPreference(TIME_MIDDLE_POS, DEFAULT_ITEM_SELECTED)
        val iselmiddle2= mMySharePreferences!!.getIntPreference(TIME_MIDDLE2_POS, DEFAULT_ITEM_SELECTED)
        val iselend= mMySharePreferences!!.getIntPreference(TIME_END_POS, DEFAULT_ITEM_SELECTED)

        // convert in long
        var ltimestart = settingstimestart[iselstart].substring(0,2).toLong()
        var ltimemiddle = settingstimemiddle[iselmiddle].substring(0,2).toLong()
        var ltimemiddle2 = settingstimemiddle2[iselmiddle2].substring(0,2).toLong()
        var ltimeend = settingstimeend[iselend].substring(0,2).toLong()
        Log.d(LOG_TAG, "Al setHourMinutes ltimestart " + ltimestart +
            " ltimemiddle " + ltimemiddle + " ltimemiddle2 " + ltimemiddle2
            + " ltimeend " + ltimeend)


        // create time ranges with long values
        ltimestart = ltimestart*60*60
        ltimemiddle = ltimemiddle*60*60
        ltimemiddle2 = ltimemiddle2*60*60
        ltimeend = ltimeend*60*60

        // add the minutes
        ltimestart += settingstimestart[iselstart].substring(4).toLong()*60
        ltimemiddle += settingstimemiddle[iselmiddle].substring(4).toLong()*60
        ltimemiddle2 += settingstimemiddle2[iselmiddle2].substring(4).toLong()*60
        ltimeend += settingstimeend[iselend].substring(4).toLong()*60

        Log.d(LOG_TAG, "Al setHourMinutes add minutes " + ltimestart +
                " ltimemiddle " + ltimemiddle + " ltimemiddle2 " + ltimemiddle2
                + " ltimeend " + ltimeend)
        val r = Random()
        var incVal: Long
        val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm:ss")

        do
        {

            val coef = (1 + 99 * r.nextDouble())/100
            // get the time range morning or afternoon
            Log.d(LOG_TAG, "Al setHourMinutes percentage " + coef)

            if (r.nextBoolean())
            {
                // set the hour and minutes of first time range
                Log.d(LOG_TAG, "Al setHourMinutes morning settingstimestart[iselstart] " + settingstimestart[iselstart])
                calendar.set(Calendar.HOUR_OF_DAY, settingstimestart[iselstart].substring(0,2).toInt())
                calendar.set(Calendar.MINUTE, settingstimestart[iselstart].substring(4).toInt())
                Log.d(LOG_TAG, "Al setHourMinutes morning " + dateFormat.format(Date(calendar.timeInMillis )))

                // this is morning
                incVal = ((coef*(ltimemiddle - ltimestart)).toLong())*1000
            }
            else
            {
                // set the hour and minutes of first time range
                Log.d(LOG_TAG, "Al setHourMinutes afternoon settingstimemiddle2[iselmiddle2] " + settingstimemiddle2[iselmiddle2])
                calendar.set(Calendar.HOUR_OF_DAY, settingstimemiddle2[iselmiddle2].substring(0,2).toInt())
                calendar.set(Calendar.MINUTE, settingstimemiddle2[iselmiddle2].substring(4).toInt())
                Log.d(LOG_TAG, "Al setHourMinutes afternoon " + dateFormat.format(Date(calendar.timeInMillis )))

                // this is afternoon
                incVal = ((coef*(ltimeend - ltimemiddle2)).toLong())*1000
            }
            if ( (calendar.timeInMillis + ltimeend) < System.currentTimeMillis()){
                Log.d(LOG_TAG, "Al setHourMinutes go to next day ")
                calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) + getNextDayIndex(calendar.get(Calendar.DAY_OF_WEEK)))
            }
        } while ( (calendar.timeInMillis + incVal) < System.currentTimeMillis())

        Log.d(LOG_TAG, "Al setHourMinutes incVal " + incVal)
        calendar.timeInMillis += incVal
        Log.d(LOG_TAG, "Al setHourMinutes " + dateFormat.format(Date(calendar.timeInMillis )))

        return calendar.timeInMillis
    }


    private fun displayInfo(text: String){
        mHandler.post( Runnable {
            Toast.makeText(this, text, Toast.LENGTH_LONG).show()
        })

    }

    private fun sendActionNotif(messageTextSms: String, messageText: String){
        Log.d(LOG_TAG, "sendActionNotif")
        if (resources.getBoolean(R.bool.notification_useservice)) {
            sendMessage(messageTextSms, messageText,
                    getString(R.string.app_name))
        }
        else
        {
            Log.d(LOG_TAG, "sendActionNotif not via service")
        }
    }

    private fun sendAlertMessage(){
        Log.d(LOG_TAG, "sendAlertMessage ")
        // send Alert message
        if (resources.getBoolean(R.bool.notification_useservice)) {
            sendMessage(getString(R.string.alert_message_textsms),
                    getString(R.string.alert_message_text),
                    getString(R.string.alert_subject_text))
        }
        else
        {
            Log.d(LOG_TAG, "sendAlertMessage not via service")
        }

    }

    private fun sendMessage(messageTextSms: String, messageText: String, messageSubject: String){
        Log.d(LOG_TAG, "sendMessage")
        if (!messageText.isEmpty()) {
            Log.d(LOG_TAG, "sendMessage messageText")

            var bSentSMS:Boolean = false;
            // send Action notification by SMS
            val smsPhonenumbers = mMySharePreferences?.getStringPreference(Constants.SMS_PHONENUMBERS)
            if (smsPhonenumbers != null && !smsPhonenumbers.isEmpty()
                    && !messageTextSms.isEmpty()) {
                if (!mMySMSManager!!.notifyBySMS(smsPhonenumbers, messageTextSms)) {
                    displayInfo(resources.getString(R.string.sms_error))
                }else{
                    // notify also by email bSentSMS = true
                }
            } else {
                Log.d(LOG_TAG, "sendMessage no smsPhonenumbers!")
            }

            if (!bSentSMS)
            {
                Log.d(LOG_TAG, "sendMessage try to send the message by email")
                // sent by email
                val emailToAdr = mMySharePreferences?.getStringPreference(Constants.EMAILS_ADR)
                if (emailToAdr != null && !emailToAdr.isEmpty()) {
                    if (mHttpRequestHelper!!.postRequestAlert(getString(R.string.app_name),
                                    messageText,
                                    messageSubject,
                                    emailToAdr) < 300) {
                        displayInfo(resources.getString(R.string.sendmessage_successfully_sent)
                                + " " + emailToAdr)
                    } else {
                        displayInfo(resources.getString(R.string.sendmessage_error))
                    }
                } else {
                    Log.d(LOG_TAG, "sendMessage no emailToAdr!")
                }
            }

        }
        else
        {
            Log.d(LOG_TAG, "sendActionNotif no text!")
        }
    }

}