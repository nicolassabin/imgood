package com.nicsabsoft.imgoodapp


import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_operationvalidate.*
import com.nicsabsoft.imgoodapp.core.alarm.AlarmScenario


open class OperationValidateActivity : AppBasedActivity(), AlarmScenario.IAlarmScenario {

    companion object {

        private const val LOG_TAG = "OpeActivity";

    }

    /** The m mAlarmScenario.  */
    protected var mAlarmScenario : AlarmScenario? = null

    /** The m mbValidationFromBack.  */
    protected var mbValidationFromBack: Boolean? = true

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d( LOG_TAG, "onCreate")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_operationvalidate)

        mTheApplication?.showMessageNotification(NOTIF_ID, resources.getString(R.string.notif_alert_msg))
        mProgressBar = this.progressBar_cyclic

        mAlarmScenario = AlarmScenario(this, this.imageOperation, this)
        mAlarmScenario?.init("alarmstep")

        this.buttonValidate?.setOnClickListener {
            Log.d( LOG_TAG, "buttonValidate setOnClickListener")
            validateOperation(true)
        }

        this.buttonNotValidate?.setOnClickListener {
            Log.d( LOG_TAG, "buttonValidate setOnClickListener")
            notValidateOperation(true)
        }

    }

    override fun onResume() {
        Log.d( LOG_TAG, "onResume")
        // 1
        super.onResume()
        startAlarm()

    }
    override fun onBackPressed() {
        Log.d( LOG_TAG, "onBackPressed")
        if (mbValidationFromBack!!) validateOperation(true)

        super.onBackPressed()
    }

    override fun onPause() {
        Log.d( LOG_TAG, "onPause")
        super.onPause()
    }

    override fun onDestroy() {
        Log.d( LOG_TAG, "onDestroy")
        mAlarmScenario?.removeCallbacks()
        super.onDestroy()

    }

    protected fun validateOperation(bSetNextAlarm: Boolean)
    {
        Log.d( LOG_TAG, "validateOperation nSetNextAlarm $bSetNextAlarm")
        stopAlarm()
        sendNotification(getString(R.string.message_confirmation_imgood_smstext),
                getString(R.string.message_confirmation_imgood_text))
        if (bSetNextAlarm) {
            setNextAlarm()
            finish()
        }

    }

    protected fun notValidateOperation(bSetNextAlarm: Boolean)
    {
        Log.d( LOG_TAG, "notValidateOperation")
        stopAlarm()
        sendNotification(getString(R.string.message_confirmation_imnotgood_smstext),
                getString(R.string.message_confirmation_imnotgood_text))

        if (bSetNextAlarm) {
            setNextAlarm()
            finish()
        }
    }

    private fun startAlarm()
    {
        Log.d( LOG_TAG, "startAlarm")

        mAlarmScenario!!.start()

    }

    private fun stopAlarm()
    {
        Log.d( LOG_TAG, "stopAlarm")

        mAlarmScenario!!.stop()


    }

    override fun notifyEndAlarmScenario() {
        Log.d( LOG_TAG, "notifyEndAlarmScenario")
        sendAlertMessage()
    }

}

