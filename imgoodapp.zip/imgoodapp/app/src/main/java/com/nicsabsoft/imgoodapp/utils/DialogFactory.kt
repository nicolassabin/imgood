package com.nicsabsoft.imgoodapp.utils

import android.app.Activity
import android.app.Dialog
import android.util.Log

/**
 * Created by nsab0001 on 17/05/2017.
 */

object DialogFactory {

    private val LOG_TAG = "DialogFactory"

    /**
     * Show dialog.
     * @param activity the activity
     * @param dialog the dialog
     */
    fun showDialog(activity: Activity?, dialog: Dialog?) {
        if (activity == null || dialog == null)
            return

        activity.runOnUiThread {
            if (dialog.ownerActivity == null || dialog.ownerActivity!!.isFinishing) {
                Log.d(LOG_TAG, "showDialog ignored")
            } else if (!dialog.isShowing) {
                try {
                    dialog.show()
                } catch (ignored: Exception) {
                    Log.e(LOG_TAG, "showDialog, exc: %s", ignored)
                }

            }
        }
    }
}
