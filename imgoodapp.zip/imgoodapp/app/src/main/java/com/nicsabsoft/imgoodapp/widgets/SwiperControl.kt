/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.nicsabsoft.imgoodapp.widgets

import android.content.Context
import android.os.Handler
import android.os.Message
import android.support.v4.view.MotionEventCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout

import com.nicsabsoft.imgoodapp.R

import java.lang.ref.WeakReference

/**
 * The Class SwiperControl.
 */
class SwiperControl
/**
 * Instantiates a new swiper control.
 * @param context the context
 * @param attrs the attrs
 */
(
        /** The context.  */
        private val mContext: Context, attrs: AttributeSet) : LinearLayout(mContext, attrs), ViewPager.OnPageChangeListener, View.OnTouchListener {

    /** The ViewPager.  */
    private var mViewPager: ViewPager? = null

    /** The mCurrentItem.  */
    private val mCurrentItem = 1

    /** The prev position.  */
    private val mPrevPosition = -1

    /** The page change listner.  */
    private var mPageChangeListner: SwipePageListener? = null

    /** The circle page indicator.  */
    /**
     * Gets the circle page indicator.
     * @return the indicator
     */
    var circlePageIndicator: CirclePageIndicator? = null
        private set

    /** The auto scroll time in milliseconds, default is [.AUTO_SCROLL_DEFAULT_INTERVAL]  */
    private var mAutoScrollInterval = AUTO_SCROLL_DEFAULT_INTERVAL.toLong()

    /** The auto scroll direction, default is [.AUTO_SCROLL_RIGHT]  */
    private var mAutoScrollDirection = AUTO_SCROLL_RIGHT

    /** Whether automatic cycle when auto scroll reaching the last or first item, default is true  */
    private var mIsAutoScrollCycle = true

    /** Whether stop auto scroll when touching, default is true  */
    private val mStopScrollWhenTouch = true

    /** Auto scroll stopped by touch  */
    private var mIsStoppedByTouch = false

    /** Auto scroll handler  */
    private val mAutoScrollHandler = AutoScrollHandler(this)

    /** If true viewpager doing auto scroll */
    private var mIsAutoScroll = false

    /**
     * Gets the num views.
     * @return the num views
     */
    val numViews: Int
        get() = mViewPager!!.adapter.count

    init {

        initView()

        val a = mContext.obtainStyledAttributes(attrs, R.styleable.UIWidgetsSwiperControl)
        if (a != null) {
            mIsAutoScroll = a.getBoolean(R.styleable.UIWidgetsSwiperControl_autoScroll, mIsAutoScroll)
            mIsAutoScrollCycle = a.getBoolean(R.styleable.UIWidgetsSwiperControl_autoScrollCycle, mIsAutoScrollCycle)
            mIsStoppedByTouch = a.getBoolean(R.styleable.UIWidgetsSwiperControl_autoScrollStoppedByTouch, mIsStoppedByTouch)
            mAutoScrollDirection = a.getInteger(R.styleable.UIWidgetsSwiperControl_autoScrollDirection, mAutoScrollDirection)
            mAutoScrollInterval = a.getInteger(R.styleable.UIWidgetsSwiperControl_autoScrollInterval, mAutoScrollInterval.toInt()).toLong()
            if (mIsAutoScroll) {
                startAutoScroll()
            }
            a.recycle()
        }
    }

    /**
     * Inits the view.
     */
    @Synchronized
    private fun initView() {
        val vi = mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        vi.inflate(R.layout.uiwidgets_swiper_control, this, true)
        // initialize the inner controls
        mViewPager = findViewById<View>(R.id.swipe_flipper) as ViewPager
        mViewPager!!.isClickable = false
        mViewPager!!.setOnTouchListener(this)
    }

    /**
     * Sets the adapter.
     * @param adapter the new adapter
     */
    fun setAdapter(adapter: PagerAdapter) {
        mViewPager!!.adapter = adapter
        circlePageIndicator = findViewById<View>(R.id.indicator) as CirclePageIndicator
        val indicator = circlePageIndicator
        indicator!!.setViewPager(mViewPager!!)
        indicator.setOnPageChangeListener(this)

        if (adapter.count < 2) {
            indicator.visibility = View.GONE
        }
    }

    /**
     * Sets the page change listner.
     * @param pageChangeListner the new page change listner
     */
    fun setPageChangeListner(pageChangeListner: SwipePageListener) {
        this.mPageChangeListner = pageChangeListner
    }

    /**
     * @see android.support.v4.view.ViewPager.OnPageChangeListener.onPageScrolled
     */
    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
        if (mPageChangeListner != null) {
            mPageChangeListner!!.onPageScrolled(position, positionOffset, positionOffsetPixels)
        }
    }

    /**
     * @see android.support.v4.view.ViewPager.OnPageChangeListener.onPageSelected
     */
    override fun onPageSelected(position: Int) {
        if (mPageChangeListner != null) {
            mPageChangeListner!!.onPageSelected(position)
        }
    }

    /**
     * @see android.support.v4.view.ViewPager.OnPageChangeListener.onPageScrollStateChanged
     */
    override fun onPageScrollStateChanged(state: Int) {
        if (mPageChangeListner != null) {
            mPageChangeListner!!.onPageScrollStateChanged(state)
        }
    }

    /**
     * Start auto scroll
     */
    private fun startAutoScroll() {
        mIsAutoScroll = true
        sendScrollMessage(mAutoScrollInterval)
    }

    /**
     * Start auto scroll
     *
     * @param delayTimeInMills first scroll delay time
     */
    fun startAutoScroll(delayTimeInMills: Int) {
        mIsAutoScroll = true
        mAutoScrollInterval = delayTimeInMills.toLong()
        sendScrollMessage(mAutoScrollInterval)
    }

    /**
     * Stop auto scroll
     */
    private fun stopAutoScroll() {
        mIsAutoScroll = false
        mAutoScrollHandler.removeMessages(SCROLL_WHAT)
    }

    /**
     * Send delayed message for scrolling to the next page
     * @param delayTimeInMills
     */
    private fun sendScrollMessage(delayTimeInMills: Long) {
        /** remove messages before, keeps one message is running at most  */
        mAutoScrollHandler.removeMessages(SCROLL_WHAT)
        mAutoScrollHandler.sendEmptyMessageDelayed(SCROLL_WHAT, delayTimeInMills)
    }

    /**
     * Scroll only once
     * @return true if view scrolled, false if not
     */
    fun scrollOnce(): Boolean {
        val adapter = mViewPager!!.adapter
        var currentItem = mViewPager!!.currentItem
        val totalCount: Int
        totalCount = adapter.count
        if (adapter == null || (totalCount) <= 1) {
            return false
        }

        val nextItem = if (mAutoScrollDirection == AUTO_SCROLL_LEFT) --currentItem else ++currentItem
        if (nextItem < 0) {
            if (mIsAutoScrollCycle) {
                mViewPager!!.setCurrentItem(totalCount - 1, true)
                return true
            }
        } else if (nextItem == totalCount) {
            if (mIsAutoScrollCycle) {
                mViewPager!!.setCurrentItem(0, true)
                return true
            }
        } else {
            mViewPager!!.setCurrentItem(nextItem, true)
            return true
        }
        return false
    }

    override fun onTouch(view: View, motionEvent: MotionEvent): Boolean {
        val action = MotionEventCompat.getActionMasked(motionEvent)
        if (mStopScrollWhenTouch) {
            if (action == MotionEvent.ACTION_DOWN) {
                if (mIsAutoScroll) {
                    mIsStoppedByTouch = true
                    stopAutoScroll()
                } else if (mIsStoppedByTouch) {
                    mIsStoppedByTouch = false
                    startAutoScroll()
                }
            }
        }

        return false
    }

    private class AutoScrollHandler(autoScrollViewPager: SwiperControl) : Handler() {

        private val mSwiperControlWeakReference: WeakReference<SwiperControl>

        init {
            this.mSwiperControlWeakReference = WeakReference(autoScrollViewPager)
        }

        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)

            when (msg.what) {
                SCROLL_WHAT -> {
                    val pager = mSwiperControlWeakReference.get()
                    if (pager != null) {
                        pager.scrollOnce()
                        pager.sendScrollMessage(pager.mAutoScrollInterval)
                    }
                }
                else -> {
                }
            }
        }
    }

    companion object {

        /** The default auto scroll time in milliseconds  */
        const val AUTO_SCROLL_DEFAULT_INTERVAL = 3000
        const val AUTO_SCROLL_LEFT = 0
        const val AUTO_SCROLL_RIGHT = 1

        const val SCROLL_WHAT = 0x4651
    }
}
