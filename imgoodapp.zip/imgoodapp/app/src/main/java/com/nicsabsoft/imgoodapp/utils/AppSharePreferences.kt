/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.nicsabsoft.imgoodapp.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor


/**
 * The Class PreferencesEndPointImpl.
 */

@SuppressLint("ApplySharedPref")
abstract class AppSharePreferences
/**
 * Instantiates a new preferences end point impl.
 * @param context the context
 * @param preferencesName the preferences name
 */
(
        /** The m context app.  */
        protected val mContextApp: Context,
        /** The m preferences name.  */
        protected val mPreferencesName: String)// @Named("applicationLabel") String applicationLabel
{

    /**
     * @see AppSharePreferences.getSharedPreferences
     */
    val sharedPreferences: SharedPreferences
        get() = mContextApp.getSharedPreferences(mPreferencesName, 0)

    /**
     * Close editor.
     * @param editor the editor
     */
    private fun closeEditor(editor: Editor) {
        // Don't forget to commit your edits!!!
        editor.commit()
    }

    /**
     * @see AppSharePreferences.saveBooleanPreference
     */
    fun saveBooleanPreference(key: String, value: Boolean) {
        val settings = sharedPreferences
        val editor = settings.edit()
        editor.putBoolean(key, value)
        closeEditor(editor)
    }

    /**
     * @see AppSharePreferences.saveIntPreference
     */
    fun saveIntPreference(key: String, value: Int) {
        val settings = sharedPreferences
        val editor = settings.edit()
        editor.putInt(key, value)
        closeEditor(editor)
    }

    /**
     * @see AppSharePreferences.saveLongPreference
     */
    fun saveLongPreference(key: String, value: Long) {
        val settings = sharedPreferences
        val editor = settings.edit()
        editor.putLong(key, value)
        closeEditor(editor)
    }

    /**
     * @see AppSharePreferences.saveStringPreference
     */
    fun saveStringPreference(key: String, value: String) {
        val settings = sharedPreferences
        val editor = settings.edit()
        editor.putString(key, value)
        closeEditor(editor)
    }

    /**
     * @see AppSharePreferences.getBooleanPreference
     */
    fun getBooleanPreference(key: String): Boolean {
        // Restore preferences
        return sharedPreferences.getBoolean(key, false)
    }

    /**
     * @see AppSharePreferences.getBooleanPreference
     */
    fun getBooleanPreference(key: String, defValue: Boolean): Boolean {
        // Restore preferences
        return sharedPreferences.getBoolean(key, defValue)
    }

    /**
     * @see AppSharePreferences.getIntPreference
     */
    fun getIntPreference(key: String): Int {
        return sharedPreferences.getInt(key, 0)
    }

    /**
     * @see AppSharePreferences.getIntPreference
     */
    fun getIntPreference(key: String, defValue: Int): Int {
        return sharedPreferences.getInt(key, defValue)
    }

    /**
     * @see AppSharePreferences.getLongPreference
     */
    fun getLongPreference(key: String, defValue: Long): Long {
        return sharedPreferences.getLong(key, defValue)
    }

    /**
     * @see AppSharePreferences.getStringPreference
     */
    fun getStringPreference(key: String): String {
        return sharedPreferences.getString(key, "")
    }

    /**
     * @see AppSharePreferences.getStringPreference
     */
    fun getStringPreference(key: String, defValue: String): String? {
        return sharedPreferences.getString(key, defValue)
    }

    /**
     * @see AppSharePreferences.removePreference
     */
    fun removePreference(key: String) {
        val settings = sharedPreferences
        val editor = settings.edit()
        editor.remove(key)
        closeEditor(editor)
    }

    /**
     * @see AppSharePreferences.clearAll
     */
    fun clearAll() {
        val settings = sharedPreferences
        val editor = settings.edit()
        editor.clear()
        editor.commit()
    }


}
