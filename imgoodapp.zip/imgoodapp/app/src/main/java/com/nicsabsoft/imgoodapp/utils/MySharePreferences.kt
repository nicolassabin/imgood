/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.nicsabsoft.imgoodapp.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.util.Log
import com.nicsabsoft.imgoodapp.Constants


/**
 * The Class PreferencesEndPointImpl.
 */

@SuppressLint("ApplySharedPref")
class MySharePreferences(mContextApp: Context, mPreferencesName: String) : AppSharePreferences(mContextApp, mPreferencesName)
{
    companion object {

        private const val LOG_TAG = "MySharePreferences"

    }

    fun notificationValid(): Boolean {
        Log.d(LOG_TAG, "notificationValid")

        /*if (!mMySharePreferences!!.getBooleanPreference(Constants.NOTIF_ACTION, false)) {
            Log.d(LOG_TAG, "notificationValid return false")
            return false
        }

        if (mMySharePreferences!!.getBooleanPreference(Constants.NOTIF_ACTION, false)
                && mMySharePreferences!!.getStringPreference(Constants.SMS_PHONENUMBERS).isEmpty()) {
            Log.d(LOG_TAG, "notificationValid return false")
            return false
        }*/
        if (getStringPreference(Constants.SMS_PHONENUMBERS).isEmpty()
                && getStringPreference(Constants.EMAILS_ADR).isEmpty()) {
            Log.d(LOG_TAG, "notificationValid return false")
            return false
        }

        return true;
    }


}
